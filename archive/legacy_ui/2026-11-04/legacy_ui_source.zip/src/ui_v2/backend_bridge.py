# -*- coding: utf-8 -*-
"""
ui_v2.backend_bridge —— ui_v2 空壳与现有 core 模块的桥接器。

职责：
  - 把 LauncherDialog / MultiCamWorkspace / MobileChainWorkspace 的 Qt 信号
    接到现有 core 模块（CameraManager / FixedMultiCamWorkflow / MobileChainWorkflow）；
  - 把控件替换为成熟组件（EmbeddedPointCloudViewer / camera_card 等）；
  - 处理 QThread 后台执行与主线程 UI 更新的线程切换。

使用方式：
  bridge = BackendBridge(main_window_shell)
  bridge.wire_all()
"""

from __future__ import annotations

import os
import json
import subprocess
import threading
import time
from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from PySide6.QtCore import QObject, QThread, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFileDialog

from core.camera_manager import CameraManager
from core.fixed_multi_cam_workflow import FixedMultiCamWorkflow
from core.mobile_chain_workflow import MobileChainWorkflow
from core.robot_stitch_workflow import RobotStitchWorkflow
from core.marker_detector import MarkerDetector
from core.calibration_engine import CalibrationEngine
from core.stitch_engine import StitchEngine
from core.point_cloud_processor import PointCloudProcessor
from core.offline_session import OfflineSession
from core.frame_data import FrameData
from core.utils import logger, write_json_atomic, write_point_cloud_atomic
from ui_common.image_preview import numpy_to_qpixmap

from .launcher_dialog import LauncherDialog
from .dialogs import ChineseMessageBox as QMessageBox, localize_buttons
from .main_window import MainWindowShell
from .bindings import (MULTI_ACTIONS, MOBILE_ACTIONS, SHELL_ACTIONS,
                       connect_actions, validate_actions)
from .widgets.device_table import DeviceInfo


def _pairs_from_engine(engine) -> List[Dict]:
    """把 CalibrationEngine.pair_results 转为 UI 结果表格行。"""
    pairs = []
    for (ref, cam), res in engine.pair_results.items():
        if res.get('success'):
            pairs.append({
                'pair': f"{cam}→{ref}",
                'rms_mm': res['rms_mm'],
                'inlier_ratio': res['inlier_ratio'],
                'T': res.get('T'),
                'level': ('fail' if res['rms_mm'] > 2.0 or res['inlier_ratio'] < .5
                          else 'ok' if res['rms_mm'] < .5 else 'warn'),
            })
    return pairs


class PreviewCaptureThread(QThread):
    """实时取景专用采集线程。

    设计动机（2026-10-09 堆损坏崩溃排查）：
      旧实现用 UI 线程 QTimer 每 100ms 同步执行 Capture2D（SDK 单次 75ms+），
      既冻结 UI，又让"采集→转 QPixmap→释放 SDK Image"的高频生命周期全部压在
      UI 线程上；两次 0xc0000374 堆损坏崩溃（14:18 / 15:16）均发生在该流程
      运行期间。改为独立线程后：
      1. 采集/转换/释放的生命周期收敛到单一后台线程，UI 只做结果显示；
      2. 帧率由线程自行定速（默认 5fps：取景瞄准足够，同时把 SDK Image
         高频建/销的堆损坏暴露量减半；采集慢于目标帧率时不堆积、不追帧）；
      3. SDK 调用仍走 rvc_sdk_lock，与 3D 拍摄/拼接/检测自动串行。

    stop() 会等待在飞的采集完成（带超时），语义等价于旧定时器 stop：
    暂停预览后立即 3D 拍摄不会与在飞 Capture2D 并发。
    """

    frame_ready = Signal(object)  # QPixmap（已在子线程转换完成）

    def __init__(self, camera_manager, camera_id: str,
                 interval_ms: int = 200, parent=None):
        super().__init__(parent)
        self._camera_manager = camera_manager
        self._camera_id = camera_id
        self._interval_ms = interval_ms
        self._stop_flag = False

    def run(self):
        while not self._stop_flag:
            t0 = time.perf_counter()
            try:
                frame = self._camera_manager.capture_2d_preview(self._camera_id)
                if frame is not None and frame.image_np is not None:
                    pixmap = numpy_to_qpixmap(frame.image_np)
                    if pixmap is not None:
                        self.frame_ready.emit(pixmap)
            except Exception as e:
                logger.warning(f"实时取景采集异常 ({self._camera_id}): {e}")
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            self.msleep(max(10, int(self._interval_ms - elapsed_ms)))

    def request_stop(self):
        """Signal cancellation without blocking the GUI thread."""
        self._stop_flag = True

    def stop(self):
        """请求退出并等待在飞采集完成（最多 3s）。"""
        self.request_stop()
        if not self.wait(3000):
            logger.warning("预览采集线程退出超时（在飞 SDK 采集超过 3s）")


def _score_from_pairs(pairs: List[Dict]) -> int:
    """基于最大 RMS 与最小内点率加权计算质量评分 0~100。"""
    if not pairs:
        return 0
    max_rms = max(p['rms_mm'] for p in pairs)
    min_inlier = min(p['inlier_ratio'] for p in pairs)
    rms_score = max(0.0, 100.0 - max_rms * 25.0)
    return int(min(100.0, rms_score * (0.5 + 0.5 * min_inlier)))


class BackendBridge(QObject):
    """ui_v2 与 core 模块的桥接器。"""

    connection_finished = Signal(bool, str)
    """设备连接完成信号：(success, message)。"""

    def __init__(self, shell: MainWindowShell):
        super().__init__()
        self.shell = shell

        # core 模块
        self.camera_manager = CameraManager()
        self.marker_detector = MarkerDetector()
        self.calibration_engine = CalibrationEngine()
        self.stitch_engine = StitchEngine()
        self.processor = PointCloudProcessor()

        # 工作流
        self.fixed_workflow = FixedMultiCamWorkflow(
            self.camera_manager, self.marker_detector,
            self.calibration_engine, self.stitch_engine, self.processor)
        self.mobile_workflow = MobileChainWorkflow(
            self.camera_manager, self.marker_detector,
            self.calibration_engine, self.stitch_engine, self.processor)
        self.robot_workflow = RobotStitchWorkflow(
            self.camera_manager, self.marker_detector,
            self.calibration_engine, self.stitch_engine, self.processor)
        self.shell.workspace_robot().set_workflow(self.robot_workflow)
        self._robot_offline_frames = []

        # 当前模式
        self._current_mode = LauncherDialog.MODE_MULTI_CAM

        # 标记物检测器共享状态锁（set_marker_type / detect_3d 非线程安全）
        self._detect_lock = threading.Lock()

        # 模式 B 实时取景专用采集线程（生命周期收敛到单线程，见
        # PreviewCaptureThread 类注释；stop() 才重建，避免句柄泄漏）
        self._preview_thread: Optional[PreviewCaptureThread] = None
        self._preview_camera_id: Optional[str] = None

        # 模式 A 单相机卡片 2D 预览定时器
        self._card_preview_timer = QTimer(self)
        self._card_preview_timer.timeout.connect(self._on_card_preview_tick)
        self._card_preview_active: Set[str] = set()

        # 后台任务引用保护：防止 QThread 运行期间被 Python GC 销毁
        self._workers: List[WorkerThread] = []

        # Offline preview never initializes the SDK. Hardware entry points opt in.
        self._sdk_initialized = False
        self.offline_preview = False
        self._disconnecting = False
        from .frame_database import FrameDatabaseController
        self.frame_db = FrameDatabaseController(self)
        self.camera_manager.capture_sink = self.frame_db.capture
        from .session_projects import SessionProjects
        self.projects = SessionProjects(self)
        from .explicit_stitching import ExplicitStitching
        self.stitching = ExplicitStitching(self)
        from .background_recognition import BackgroundRecognition
        self.recognition = BackgroundRecognition(self)
        self.shell.workspace_turntable().background_recognition = self.recognition

    def open_postprocess(self):
        """Open the offline editor on this DB; no camera or workflow reset."""
        previous = getattr(self, '_postprocess_window', None)
        if previous is not None and not previous._closed:
            previous.raise_()
            previous.activateWindow()
            return previous
        if not self.can_change_workspace():
            self.shell.log('请等待当前任务完成后再进入点云后处理。', 'warn')
            return None
        from .postprocess.window import PostprocessWindow
        mode = self.shell.current_mode()
        browser = self.frame_db.browsers.get(mode)
        identifiers = ([uid for uid, _ in browser.checked_components('cloud')]
                       or browser.selected_ids()) if browser else []
        if not identifiers and mode in self.frame_db._displayed:
            identifiers = [self.frame_db._displayed[mode][0]]
        if not identifiers:
            database = self.frame_db.databases[mode]
            candidates = [row for row in database.records.values() if row.kind == 'result'
                and not row.intermediate_of and row.purpose != '后处理结果'
                and row.status != '来源数据已变更，请重新拼接']
            if candidates:
                identifiers = [max(candidates,key=lambda row:(row.created,row.frame_id)).uid]
        window = PostprocessWindow(self, mode)
        self._postprocess_window = window
        window.show()
        if identifiers:
            window.load_selected(identifiers, auto_intermediates=True)
        return window

    def _ensure_sdk(self):
        if not getattr(self, '_sdk_initialized', False):
            ok, msg = self.camera_manager.initialize()
            self._sdk_initialized = bool(ok)
            logger.log(20 if ok else 30, msg)
        return self._sdk_initialized

    def open_offline_preview(self, mode, on_finished=None):
        from .offline_preview import open_preview
        return open_preview(self, mode, on_finished)

    # ------------------------------------------------------------------
    # 接线入口
    # ------------------------------------------------------------------
    def wire_all(self):
        """连接所有信号到后端。"""
        if getattr(self, "_wired", False):
            return
        validate_actions(self.shell.workspace_multi(), self, MULTI_ACTIONS)
        validate_actions(self.shell.workspace_mobile(), self, MOBILE_ACTIONS)
        validate_actions(self.shell, self, SHELL_ACTIONS)
        self._wire_launcher()
        self._wire_multi_cam_workspace()
        self._wire_mobile_chain_workspace()
        self._wire_main_window()
        # 1.0.10 池合并：给转台工作区注入统一 runner，全工程只留一个引用池
        self.shell.workspace_turntable().set_background_runner(self._run_background)
        self.shell.workspace_turntable().calibration_visualization_requested.connect(self._on_turntable_visualize_calibration)
        self.shell.workspace_robot().set_background_runner(self._run_background)
        self.shell.workspace_robot().set_task_gate(self.can_change_workspace)
        self.shell.workspace_robot().result_publish_requested.connect(self._on_robot_publish)
        if hasattr(self, 'stitching'):
            self.shell.workspace_turntable()._explicit_stitch = self.stitching.execute
        self._wired = True

    def _wire_launcher(self):
        """接线启动小窗。"""
        # LauncherDialog 由 MainWindowShell.open_device_manager 创建，
        # 这里只接线 MainWindowShell 的设备管理重开信号
        self.shell.device_manager_reopened.connect(self._on_device_manager_reopened)

    def _wire_multi_cam_workspace(self):
        connect_actions(self.shell.workspace_multi(), self, MULTI_ACTIONS)

    def _wire_mobile_chain_workspace(self):
        connect_actions(self.shell.workspace_mobile(), self, MOBILE_ACTIONS)

    def _wire_main_window(self):
        connect_actions(self.shell, self, SHELL_ACTIONS)

    def connect_devices(self, mode, devices, *, show_loading=True):
        """Public startup/reconnection command, independent of launcher layout."""
        return self._on_device_manager_reopened(mode, devices, show_loading=show_loading)

    def can_change_workspace(self):
        return (not self._disconnecting and not any(worker.isRunning() for worker in self._workers)
                and not self.shell.workspace_turntable().btn_auto_capture.isChecked()
                and not self.shell.workspace_turntable()._busy)

    def disconnect_devices(self, on_finished=None):
        """Release connected devices after previews finish; keep all project data."""
        if getattr(self, '_cleaned', False):
            return False
        if not self.can_change_workspace():
            self.shell.log('当前任务进行中，请等待完成后再断开相机。', 'warn')
            return False
        connected = self.camera_manager.get_connected_ids()
        if not connected:
            self.shell.log('当前没有已连接的相机。', 'info')
            return False
        self._disconnecting = True
        # Detach first so queued preview frames cannot update the retained image.
        preview, self._preview_thread = self._preview_thread, None
        self._preview_camera_id = None
        if preview is not None:
            preview.request_stop()
        self._pause_card_preview()
        self._card_preview_timer.stop()
        self.shell.workspace_mobile().set_preview_enabled(False)
        self._refresh_device_controls(force_off=True)
        self.shell.log(f'正在断开 {len(connected)} 台相机，等待在飞预览结束…', 'info')

        def work():
            if preview is not None:
                preview.wait()  # Must finish before releasing any SDK handles.
            self.camera_manager.disconnect_all()

        def done(_, error):
            if preview is not None and not preview.isRunning():
                preview.deleteLater()
            self._disconnecting = False
            if getattr(self, '_cleaned', False):
                return
            remaining = self.camera_manager.get_connected_ids()
            self._refresh_device_controls()
            success = error is None and not remaining
            if success:
                self.shell.log(f'已断开 {len(connected)} 台相机；DB、标定和采集数据已保留。', 'success')
            else:
                self.shell.log(f'断开连接未完成：{error or "仍有相机在线"}；剩余 {len(remaining)} 台在线，可重试。', 'error')
            if on_finished is not None:
                on_finished(success)
        self._run_background(work, done, must_finish=True, name='device_disconnect')
        return True

    def _refresh_device_controls(self, *, force_off=False):
        """Change capture availability without set_devices() resetting sessions."""
        from dataclasses import replace
        remaining = [] if force_off else self.camera_manager.get_connected_ids()
        serials = {self.camera_manager._cameras[cid].sn for cid in remaining}
        multi, mobile = self.shell.workspace_multi(), self.shell.workspace_mobile()
        turn, robot = self.shell.workspace_turntable(), self.shell.workspace_robot()
        for workspace in (multi, mobile, turn):
            workspace._devices = [replace(device, online=device.serial in serials)
                                  for device in workspace._devices]
        # Reuse the existing read-only capture gates; this is not a simulated
        # offline data provider and does not change the backend workflow.
        multi.offline_preview = mobile.offline_preview = not bool(remaining)
        for cid, card in multi._camera_grid._cards.items():
            card.set_controls_enabled(cid in remaining)
            if cid not in remaining:
                card._btn_detect.setEnabled(card.current_frame() is not None)
        for workspace in (multi, mobile, turn):
            state = workspace.current_state()
            workspace.set_state('idle' if not force_off and not remaining and state == 'connected' else state)
        devices = [device for device in self.shell._devices if device.serial in serials]
        robot.set_devices(devices)
        if not force_off:
            self.shell._devices = devices
        for browser in self.frame_db.browsers.values():
            browser.properties.capture.refresh(allow_auto=False)
        status = getattr(getattr(multi, '_industrial', None), 'camera_status', None)
        if status is not None:
            status.refresh()
        self.shell._refresh_statusbar()

    def capture_parameters(self, camera_id, values, done):
        """Serialize parameter I/O with capture, without touching project/DB state."""
        if not self.can_change_workspace():
            done(None, '当前任务进行中，请稍后再试')
            return
        source = self.camera_manager.capture_parameter_source(camera_id)
        if source is None:
            done(None, '相机已断开，请重新连接后读取参数')
            return
        def completed(result, error):
            if values is not None:
                self.shell.log(f'{camera_id} 拍摄参数' + ('应用失败：' + str(error) if error else '已应用'),
                               'error' if error else 'success')
            done(result, error)
        self._run_background(
            lambda: self.camera_manager.common_capture_parameters(camera_id, values, expected_source=source),
            completed, must_finish=values is not None, name='capture_parameters')

    # ------------------------------------------------------------------
    # 参数调试：打开官方 RVCManager
    # ------------------------------------------------------------------
    def _on_param_debug(self):
        """断开当前已连接相机，打开 RVC 官方调试工具 RVCManager。

        自动按默认安装路径查找 D/C 盘；找不到时弹窗提示并允许用户
        自定义选择 RVCManager.exe 路径。
        """
        if not self.can_change_workspace():
            self.shell.log('当前任务进行中，请等待完成后再打开参数调试。', 'warn')
            return
        if self.camera_manager.get_connected_ids():
            self.disconnect_devices(lambda success: self._launch_param_debug() if success else None)
        else:
            self._launch_param_debug()

    def _launch_param_debug(self):
        """Launch RVCManager only after all device handles have been released."""
        # 2. 查找默认安装路径
        candidates = [
            r"D:\Program Files\RVBUST\RVC\RVCManager\RVCManager.exe",
            r"C:\Program Files\RVBUST\RVC\RVCManager\RVCManager.exe",
        ]
        executable: Optional[str] = None
        for path in candidates:
            if os.path.isfile(path):
                executable = path
                break

        # 3. 找不到则弹窗提示并让用户自定义路径
        if executable is None:
            self.shell.log("未在默认路径找到 RVCManager.exe", "warn")
            reply = QMessageBox.question(
                self.shell,
                "未找到 RVCManager",
                "未在以下默认路径找到 RVCManager.exe：\n"
                "D:\\Program Files\\RVBUST\\RVC\\RVCManager\\RVCManager.exe\n"
                "C:\\Program Files\\RVBUST\\RVC\\RVCManager\\RVCManager.exe\n\n"
                "是否手动指定 RVCManager.exe 路径？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if reply != QMessageBox.Yes:
                self.shell.log("已取消打开 RVCManager", "info")
                return

            default_dir = r"C:\Program Files\RVBUST\RVC\RVCManager"
            if not os.path.isdir(default_dir):
                default_dir = r"C:\\"
            executable, _ = QFileDialog.getOpenFileName(
                self.shell,
                "选择 RVCManager.exe",
                default_dir,
                "可执行文件 (*.exe)",
            )
            if not executable:
                self.shell.log("未选择 RVCManager.exe，已取消", "info")
                return
            if os.path.basename(executable) != "RVCManager.exe":
                QMessageBox.warning(
                    self.shell,
                    "路径无效",
                    "请选择 RVCManager.exe 官方调试工具。",
                )
                self.shell.log(f"选择的文件不是 RVCManager.exe: {executable}", "warn")
                return

        # 4. 打开官方调试工具
        try:
            subprocess.Popen([executable], shell=False)
            self.shell.log(f"已启动 RVCManager: {executable}", "success")
        except Exception as e:
            self.shell.log(f"启动 RVCManager 失败: {e}", "error")
            QMessageBox.critical(
                self.shell,
                "启动失败",
                f"无法启动 RVCManager：\n{e}\n\n"
                f"请检查路径是否正确或尝试以管理员身份运行。",
            )

    # ------------------------------------------------------------------
    # 连接失败诊断与提示
    # ------------------------------------------------------------------
    @staticmethod
    def _classify_connection_failure(
        results: List[Tuple[str, bool, str]],
        real_devices: List[DeviceInfo],
        required: int,
        total_count: Optional[int] = None,
    ) -> Tuple[str, str]:
        """根据连接结果构造用户友好的失败原因和排查建议。

        Args:
            total_count: 总设备数（含测试相机）。为 None 时取 len(results)。

        Returns:
            (reason, details) 分别用于弹窗标题下方的正文和详细说明。
        """
        ok_count = sum(1 for _, ok, _ in results if ok)
        total_count = total_count if total_count is not None else len(results)
        failures = [(cid, msg) for cid, ok, msg in results if not ok]

        # 1. 设备总数不足（含只选测试相机但数量不够）
        if total_count < required:
            if not real_devices:
                return (
                    f"当前仅选择了 {total_count} 台测试相机（仅用于 UI 布局预览），"
                    f"该模式需要至少 {required} 台设备。",
                    "调试 UI 时可选择多台测试相机进入；"
                    "正式使用请检查真实 RVC 相机是否已上电、网线/USB 是否连接正常，"
                    "然后点击「刷新」重新枚举设备并勾选真实相机。",
                )
            return (
                f"该模式需要至少 {required} 台设备，当前仅 {total_count} 台。",
                "请继续勾选更多设备，或检查真实相机的连接状态。",
            )

        # 2. 有真实设备但全部连接失败
        if ok_count == 0 and failures:
            msgs = "\n".join(f"  • {cid}: {msg}" for cid, msg in failures)
            busy = any("占用" in msg or "RVCManager" in msg for _, msg in failures)
            if busy:
                reason = "所有真实相机均连接失败，检测到相机可能被占用。"
                details = (
                    f"失败详情：\n{msgs}\n\n"
                    "常见原因与解决方法：\n"
                    "  1. RVCManager 或其他调试工具正在占用相机："
                    "请关闭 RVCManager 后再点击「连接设备」。\n"
                    "  2. 本软件已连接过该相机：请尝试点击「设备管理」重新进入小窗连接。\n"
                    "  3. 相机被其他程序占用：请检查任务管理器，结束相关进程后重试。"
                )
            else:
                reason = "所有真实相机均连接失败。"
                details = (
                    f"失败详情：\n{msgs}\n\n"
                    "常见原因与解决方法：\n"
                    "  1. 相机未上电或网线/USB 松动：请检查物理连接。\n"
                    "  2. 相机 IP 不在同一网段：请点击「自动设置 IP」。\n"
                    "  3. 防火墙或杀毒软件拦截：请临时关闭后重试。"
                )
            return reason, details

        # 3. 部分成功但真实相机数量不足
        msgs = "\n".join(f"  • {cid}: {msg}" for cid, msg in failures)
        return (
            f"该模式需要至少 {required} 台设备，当前 {total_count} 台已选择，"
            f"但仅 {ok_count} 台真实相机成功连接。",
            f"失败详情：\n{msgs}\n\n"
            "当前仍可用测试相机进入工作区调试 UI；"
            "正式拍摄/标定请检查失败相机的连接状态，排除被占用或网络问题后重试。",
        )

    def _show_connection_error(self, title: str, reason: str, details: str):
        """弹出带排查建议的连接失败提示框。"""
        msg_box = QMessageBox(self.shell)
        msg_box.setWindowTitle(title)
        msg_box.setIcon(QMessageBox.Warning)
        msg_box.setText(reason)
        msg_box.setInformativeText(details)
        msg_box.setStandardButtons(QMessageBox.Ok)
        localize_buttons(msg_box)
        msg_box.exec()

    def _show_debug_mode_notice(
        self, mode_name: str, real_ok_count: int, test_count: int
    ):
        """提示当前以测试相机为主进入调试模式，正式功能需要真实相机。"""
        self.shell.log(
            f"{mode_name} 以调试模式进入：真实相机 {real_ok_count} 台，"
            f"测试设备 {test_count} 台", "warn")
        msg_box = QMessageBox(self.shell)
        msg_box.setWindowTitle(f"{mode_name} — 调试模式")
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setText(
            f"当前已使用 {test_count} 台测试相机进入 {mode_name} 工作区。\n"
            f"真实相机成功连接 {real_ok_count} 台。")
        msg_box.setInformativeText(
            "测试相机仅用于 UI 布局调试：\n"
            "  • 可以正常查看界面布局、操作流程和大部分交互；\n"
            "  • 拍摄、标定、拼接等依赖真实数据的功能会失败或无结果；\n"
            "  • 正式使用时请连接真实 RVC 相机。\n\n"
            "如果刚用过「参数调试」打开 RVCManager，请关闭 RVCManager 后"
            "重新连接真实相机。")
        msg_box.setStandardButtons(QMessageBox.Ok)
        localize_buttons(msg_box)
        msg_box.exec()

    # ------------------------------------------------------------------
    # 设备管理（LauncherDialog）
    # ------------------------------------------------------------------
    def enumerate_devices(self) -> List[DeviceInfo]:
        """枚举所有 RVC 设备并返回 DeviceInfo 列表。"""
        device_infos = []
        if not self._ensure_sdk():
            return device_infos
        if not self.can_change_workspace():
            self.shell.log('正在采集或处理任务，请稍后刷新设备状态。', 'warn')
            return device_infos
        for row in self.camera_manager.poll_device_statuses():
            device_infos.append(DeviceInfo(
                model=row.model, serial=row.serial, ip=row.ip,
                online=row.online, backend_ref=row.backend_ref,
                status=row.status, status_detail=row.detail))
        return device_infos

    def refresh_launcher_devices(self, dialog, *, selected_serials=None):
        """Poll SDK off the GUI thread; deliver only to the current open dialog."""
        if getattr(self, '_cleaned', False) or not self.can_change_workspace():
            self.shell.log('当前任务进行中，请稍后刷新设备状态。', 'warn')
            return False
        from time import perf_counter
        from shiboken6 import isValid
        started = perf_counter()
        dialog.set_busy(True, '正在查询相机状态，请稍候…')
        active = [True]
        def closed(*_):
            active[0] = False
        dialog.finished.connect(closed)

        def work():
            # Workspace gates and all widget access stay on the GUI thread.
            if not self._ensure_sdk():
                raise RuntimeError('相机 SDK 初始化失败，请查看日志')
            return [DeviceInfo(model=row.model, serial=row.serial, ip=row.ip,
                               online=row.online, backend_ref=row.backend_ref,
                               status=row.status, status_detail=row.detail)
                    for row in self.camera_manager.poll_device_statuses()]

        def done(devices, error):
            logger.info('相机状态查询耗时 %.3fs', perf_counter() - started)
            if not isValid(dialog):
                return
            dialog.finished.disconnect(closed)
            dialog.set_busy(False)
            if not active[0]:
                return
            if error is not None:
                self.shell.log(f'查询相机状态失败：{error}', 'error')
                dialog.log_summary.append(f'查询相机状态失败：{error}', 'error')
            else:
                if selected_serials is not None:
                    for device in devices:
                        device.checked = bool(device.serial and device.serial in selected_serials)
                dialog.set_devices(devices)

        self._run_background(work, done, name='device_status')
        return True

    @staticmethod
    def get_ordered_devices(devices: List[DeviceInfo]) -> List[DeviceInfo]:
        """对齐 backend 连接顺序：真实设备在前，测试/虚拟设备在后。

        LauncherDialog 返回的勾选顺序是用户点击顺序；camera_id 分配必须
        与 backend 的 ordered_devices（real + test）一致，否则卡片标题与
        实际视频帧错位。
        """
        real = [d for d in devices if isinstance(d.backend_ref, int)]
        test = [d for d in devices if not isinstance(d.backend_ref, int)]
        return real + test

    def auto_configure_network(self, devices: List[DeviceInfo],
                               on_finished=None):
        """对勾选设备自动配置 IP；未勾选则对所有 GigE 设备配置（后台执行）。

        Args:
            devices: 勾选设备列表；空列表表示所有 GigE 设备。
            on_finished: 完成回调，签名为 (results, error)，可选。
        """
        indices = [d.backend_ref for d in devices
                   if isinstance(d.backend_ref, int)]
        if devices and not indices:
            message = '测试设备不支持自动配置 IP；请接入真实 GigE 相机并刷新设备列表。'
            self.shell.log(message, 'warn')
            if on_finished is not None:
                on_finished([(-1, False, message)], None)
            return
        if not self._ensure_sdk():
            if on_finished:
                on_finished([], '相机 SDK 初始化失败')
            return
        target_desc = f"选中 {len(indices)} 台" if indices else "所有 GigE"
        self.shell.log(f"开始对 {target_desc} 设备进行自动 IP 配置...", "info")

        def _work():
            return self.camera_manager.auto_configure_network(indices)

        def _done(results, error):
            if error:
                self.shell.log(f"自动配置 IP 失败: {error}", "error")
            else:
                for idx, ok, msg in results:
                    level = "success" if ok else "warn"
                    self.shell.log(f"[{idx}] {msg}", level)
            if on_finished is not None:
                on_finished(results, error)

        self._run_background(_work, _done)

    def _on_device_manager_reopened(
        self, mode: str, devices: List[DeviceInfo], show_loading: bool = True
    ):
        """设备管理小窗确认：断开旧设备 → 连接新设备 → 切换工作区。

        Args:
            show_loading: 是否在主窗口显示 loading 遮罩。
                          主程序新流程会在 launcher 小窗上先显示遮罩，
                          因此调用时传入 False。
        """
        if self._disconnecting:
            self.connection_finished.emit(False, '正在断开相机，请等待完成后再连接')
            return
        if not self._ensure_sdk():
            self.connection_finished.emit(False, '相机 SDK 初始化失败，请查看日志')
            return
        # Connecting devices changes live capture availability, not the archived
        # calibration inputs already loaded in this workspace.
        calibration_frames = (dict(self.fixed_workflow.frames_calib)
                              if mode == LauncherDialog.MODE_MULTI_CAM
                              and self.shell._presentation == 'industrial' else {})
        self.offline_preview = False
        self.shell._offline_preview = False
        self._offline_clouds = {}
        self._robot_offline_frames = []
        self.shell.workspace_robot().set_capture_provider(None)
        for workspace in (self.shell.workspace_multi(), self.shell.workspace_mobile(),
                          self.shell.workspace_turntable(), self.shell.workspace_robot()):
            workspace.offline_preview = False
        if show_loading:
            self.shell.show_loading("正在连接设备...")
        self._pause_2d_preview()
        self._pause_card_preview()
        # 清空旧相机注册表（避免多次进入设备管理后 camera_id 递增错乱）
        self.camera_manager.clear()
        self.shell.workspace_mobile().live_view().set_frame(None)

        # 区分真实设备与测试/虚拟设备
        real_devices = [d for d in devices if isinstance(d.backend_ref, int)]
        test_devices = [d for d in devices if not isinstance(d.backend_ref, int)]
        ordered_devices = real_devices + test_devices

        # 连接新设备
        def _connect():
            results = []
            for dev in ordered_devices:
                camera_id = f"cam{len(self.camera_manager.camera_ids)}"
                self.camera_manager.add_camera(camera_id)
                if dev in test_devices:
                    # 测试设备仅占用 camera_id，不连接真实相机
                    results.append((camera_id, False, "测试设备（仅布局）"))
                    continue
                idx = dev.backend_ref  # type: ignore[union-attr]
                ok, msg = self.camera_manager.connect(camera_id, idx,
                                                      expected_sn=dev.serial or '', expected_model=dev.model)
                results.append((camera_id, ok, msg))
            return results

        def _done(results, error):
            if error:
                if show_loading:
                    self.shell.hide_loading()
                self.connection_finished.emit(False, f"连接设备异常: {error}")
                self.shell.log(f"连接设备异常: {error}", "error")
                self._show_connection_error(
                    "连接设备异常",
                    f"连接过程中发生异常：{error}",
                    details="请检查相机是否上电、网络是否正常，或尝试重新插拔相机后重试。")
                return
            ok_count = sum(1 for _, ok, _ in results if ok)
            total_count = len(results)
            real_count = len(real_devices)
            test_count = len(test_devices)
            for cid, ok, msg in results:
                level = "success" if ok else "warn"
                self.shell.log(f"相机 {cid}: {msg}", level)
            self.shell.log(
                f"设备连接完成: {ok_count}/{real_count} 台真实相机成功，"
                f"测试设备 {test_count} 台", "info")
            self._current_mode = mode
            if self.shell._presentation == 'industrial':
                self.frame_db.databases[mode].begin_session('相机采集')

            # 若用户勾选了真实相机但全部连接失败，阻断进入工作区并给出排查建议
            if real_count > 0 and ok_count == 0:
                reason, details = self._classify_connection_failure(
                    results, real_devices, required=1,
                    total_count=real_count)
                self.shell.log(
                    "所有真实相机连接失败，未进入工作区", "error")
                if show_loading:
                    self.shell.hide_loading()
                self._show_connection_error(
                    "相机连接失败", reason, details)
                self.connection_finished.emit(
                    False, "所有真实相机连接失败")
                return

            if mode == LauncherDialog.MODE_MULTI_CAM:
                # 模式 A：多相机外参标定要求至少 2 台设备（真实或测试均可进入 UI）
                if total_count < 2:
                    reason, details = self._classify_connection_failure(
                        results, real_devices, required=2,
                        total_count=total_count)
                    self.shell.log(
                        f"多相机外参标定需要至少 2 台设备，当前仅 {total_count} 台",
                        "error")
                    if show_loading:
                        self.shell.hide_loading()
                    self._show_connection_error(
                        "无法进入多相机外参标定", reason, details)
                    self.connection_finished.emit(
                        False,
                        f"多相机外参标定需要至少 2 台设备，当前 {total_count} 台")
                    return
                if ok_count < 2 and test_count > 0:
                    self._show_debug_mode_notice(
                        "多相机外参标定", ok_count, test_count)
                # 参考相机选第一台真实连接成功的相机，fallback 到 cam0
                reference_id = next(
                    (cid for cid, ok, _ in results if ok), "cam0")
                if calibration_frames:
                    self._on_multi_reference_changed(reference_id, calibration_frames=calibration_frames)
                else:
                    ok, msg = self.fixed_workflow.start_calibration(reference_id)
                    self.shell.log(msg, "success" if ok else "warn")
                    self._on_multi_reference_changed(reference_id)
                    self.shell.workspace_multi().set_state("connected")
                # 崩溃兜底：上次标定成功时已自动落盘，相机组合未变则直接
                # 恢复到扫描阶段，无需重新拍摄标定帧/计算外参
                self._try_restore_autosaved_calibration(reference_id)
            elif mode == LauncherDialog.MODE_MOBILE_CHAIN:
                # 模式 B：单相机移动拼接要求至少 1 台设备
                if total_count < 1:
                    reason, details = self._classify_connection_failure(
                        results, real_devices, required=1,
                        total_count=total_count)
                    self.shell.log(
                        "单相机移动拼接需要至少 1 台设备", "error")
                    if show_loading:
                        self.shell.hide_loading()
                    self._show_connection_error(
                        "无法进入单相机移动拼接", reason, details)
                    self.connection_finished.emit(
                        False, "单相机移动拼接需要至少 1 台设备")
                    return
                if ok_count < 1 and test_count > 0:
                    self._show_debug_mode_notice(
                        "单相机移动拼接", ok_count, test_count)
                # 模式 B 需要初始化链式拼接会话
                if self.mobile_workflow.station_manager is None:
                    ok, msg = self.mobile_workflow.start_chaining()
                    self.shell.log(msg, "success" if ok else "warn")
                if self.shell._presentation == 'industrial':
                    self.projects.prepare(mode)
                self.shell.workspace_mobile().set_state("connected")
            elif mode == LauncherDialog.MODE_TURNTABLE:
                # 模式 C：转台要求至少 1 台设备（真实或测试均可进入 UI）
                if total_count < 1:
                    reason, details = self._classify_connection_failure(
                        results, real_devices, required=1,
                        total_count=total_count)
                    self.shell.log(
                        "转台 360° 拼接需要至少 1 台设备", "error")
                    if show_loading:
                        self.shell.hide_loading()
                    self._show_connection_error(
                        "无法进入转台 360° 拼接", reason, details)
                    self.connection_finished.emit(
                        False, "转台 360° 拼接需要至少 1 台设备")
                    return
                if ok_count < 1 and test_count > 0:
                    self._show_debug_mode_notice(
                        "转台 360° 拼接", ok_count, test_count)
                # 转台工作区接入主程序共享的相机管理器
                self.shell.workspace_turntable().set_camera_manager(
                    self.camera_manager, self.marker_detector)
                self.shell.workspace_turntable().set_state("connected")
            elif mode == LauncherDialog.MODE_ROBOT:
                if total_count < 1:
                    self.shell.log('机器人手眼拼接需要至少 1 台设备', 'error')
                    if show_loading:
                        self.shell.hide_loading()
                    self.connection_finished.emit(False, '机器人手眼拼接需要至少 1 台设备')
                    return
                if ok_count < 1 and test_count > 0:
                    self._show_debug_mode_notice('机器人手眼拼接', ok_count, test_count)
                self.shell.workspace_robot().set_capture_provider(None)
                self.shell.workspace_robot().set_state('connected')
            if show_loading:
                self.shell.hide_loading()
            self.connection_finished.emit(
                True,
                f"设备连接完成: {ok_count}/{real_count} 台真实相机成功"
                f"（测试设备 {test_count} 台）")

        self._run_background(_connect, _done)

    # ------------------------------------------------------------------
    # 模式 A（多相机外参标定）
    # ------------------------------------------------------------------
    def _on_multi_capture(self, sync: bool):
        """拍摄标定帧；若已处于扫描/锁定阶段，则先重置为重新标定。"""
        ws = self.shell.workspace_multi()

        # locked 状态下点击「重新标定」：先回到标定阶段并清空旧结果
        if ws.current_state() == "locked":
            ref_id = self.calibration_engine.reference_id or ws.current_reference_id() or "cam0"
            ok, msg = self.fixed_workflow.start_calibration(ref_id)
            if not ok:
                self.shell.log(f"重新标定失败: {msg}", "error")
                return
            ws.clear_calibration_results()
            ws.viewer().clear_all()
            ws.viewer().set_reference(None)
            ws.set_state("connected")
            self.shell.log("已回到标定阶段，请重新拍摄标定帧", "info")

        preview_cam = self._pause_2d_preview()
        active_cards = self._pause_card_preview()
        self.shell.show_loading("正在拍摄标定帧...")
        def _work():
            frames = self.camera_manager.capture_all(sync=sync)
            if self.shell._presentation == 'industrial':
                return frames, {cid: frame.load_pointcloud_o3d() for cid, frame in frames.items()}
            return frames
        def _done(frames, error):
            clouds = {}
            if isinstance(frames, tuple):
                frames, clouds = frames
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            self._resume_card_preview(active_cards)
            if error:
                self.shell.log(f"拍摄失败: {error}", "error")
                return
            if not frames:
                self.shell.log("拍摄失败：无已连接相机", "warn")
                return
            # 更新工作流标定帧
            ws = self.shell.workspace_multi()
            all_ok = True
            for cid, frame in frames.items():
                ok, msg = self.fixed_workflow.add_calibration_frame(frame)
                if not ok:
                    all_ok = False
                    self.shell.log(f"添加标定帧失败 ({cid}): {msg}", "warn")
            if not all_ok:
                self.shell.log("部分标定帧未加入工作流，请检查状态", "warn")
                return
            # 更新各相机卡片预览
            for cid, frame in frames.items():
                ws.camera_grid().set_frame(cid, frame)
                if clouds.get(cid) is not None:
                    ws.viewer().set_pointcloud(cid, clouds[cid])
            ws.on_capture_done()
            ws.set_state("captured")
            self.shell.set_dirty(True)
            self.shell.log(f"拍摄完成: {len(frames)} 台相机", "success")
        self._run_background(_work, _done)

    def _on_multi_detect(self, method: str):
        """检测标记物（串行执行，避免共享 MarkerDetector 线程竞态）。"""
        if self.shell._presentation == 'industrial' and self.recognition.enabled:
            self.recognition.retry('multi_cam', [frame.database_id for frame in self.fixed_workflow.frames_calib.values()])
            return
        marker_type = self._map_detect_method(method)
        self.shell.show_loading("正在检测标记物...")

        def _detect_one(cid_frame):
            cid, frame = cid_frame
            with self._detect_lock:
                self.marker_detector.set_marker_type(marker_type)
                markers = self.marker_detector.detect_3d(
                    frame.image_np,
                    pointmap=frame.pointmap,
                    rvc_image=frame.rvc_image,
                    offline_ply_path=frame.offline_pointmap_path,
                )
            frame.markers = markers
            return cid, len(markers)

        def _work():
            frames = list(self.fixed_workflow.frames_calib.items())
            marker_counts = {}
            for cid, frame in frames:
                cid_out, count = _detect_one((cid, frame))
                marker_counts[cid_out] = count
            return marker_counts
        def _done(marker_counts, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"检测失败: {error}", "error")
                return
            ws = self.shell.workspace_multi()
            # 更新各相机卡片的标记数量与共视状态
            grid = ws.camera_grid()
            for cid, count in marker_counts.items():
                grid.set_marker_count(cid, count)
                grid.set_covis_status(cid, count > 0)
                frame = self.fixed_workflow.frames_calib.get(cid)
                if frame is not None:
                    grid.set_frame(cid, frame)
            ws.on_detect_done(marker_counts)
            ws.set_state("detected")
            self.shell.set_dirty(True)
            total = sum(marker_counts.values())
            self.shell.log(f"检测完成: 共 {total} 个标记", "success")
        self._run_background(_work, _done)

    # ------------------------------------------------------------------
    # 标定结果自动保存 / 恢复（崩溃兜底）
    # ------------------------------------------------------------------
    _AUTOSAVE_CALIBRATION_PATH = os.path.join(
        "offline_data", "autosave_calibration.json")

    def _autosave_calibration(self):
        """标定结果变更后自动落盘。

        2026-10-09 崩溃复发（原生堆损坏）后发现：标定数据只在内存中，
        崩溃后必须重新拍摄标定帧 + 计算外参。这里在标定成功 / 加载外参 /
        加载会话后自动写一份轻量外参（仅矩阵 + 相机名，不含点云帧），
        下次连接同一组相机时自动恢复到扫描阶段。文件格式与「保存外参」
        一致（仅多 camera_names / saved_at 字段，load 时忽略），可直接
        当作外参文件手动加载。
        """
        if self.shell._presentation == 'industrial' or self.offline_preview or not self.calibration_engine.pair_results:
            return
        try:
            payload = self.calibration_engine.to_dict()
            payload["camera_names"] = sorted(
                self.camera_manager.get_connected_ids())
            payload["saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            write_json_atomic(self._AUTOSAVE_CALIBRATION_PATH, payload,
                              ensure_ascii=False, indent=2)
            logger.info(
                f"[自动保存] 标定结果已落盘: {self._AUTOSAVE_CALIBRATION_PATH}")
        except Exception as e:
            logger.warning(f"标定结果自动保存失败: {e}")

    def _try_restore_autosaved_calibration(self, reference_id: str):
        """连接相机后尝试恢复自动保存的标定结果，成功则直接进入扫描阶段。

        恢复走 fixed_workflow.load_calibration（与手动「加载外参」同一条
        已验证路径）：仅恢复矩阵，不需要标定帧即可进入扫描阶段。
        """
        if self.shell._presentation == 'industrial' or self.calibration_engine.pair_results:
            return
        path = self._AUTOSAVE_CALIBRATION_PATH
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                payload = json.load(f)
        except Exception as e:
            self.shell.log(f"自动保存的标定结果读取失败: {e}", "warn")
            return
        if not payload.get("pairs"):
            return
        saved_names = sorted(payload.get("camera_names") or [])
        current_names = sorted(self.camera_manager.get_connected_ids())
        if saved_names and saved_names != current_names:
            self.shell.log(
                f"检测到自动保存的标定结果（{payload.get('saved_at')}），"
                f"但相机组合已变化（{saved_names} → {current_names}），"
                "为安全起见不自动恢复（可手动「加载外参」）", "warn")
            return
        ok, msg = self.fixed_workflow.load_calibration(path)
        if not ok:
            self.shell.log(f"自动保存的标定结果恢复失败: {msg}", "warn")
            return
        ok_scan, msg_scan = self.fixed_workflow.start_scanning()
        if ok_scan:
            ws = self.shell.workspace_multi()
            ws.viewer().set_reference(self.fixed_workflow.reference_id)
            ws.set_state("locked")
            pairs = _pairs_from_engine(self.calibration_engine)
            ws.on_calibrate_done(pairs, _score_from_pairs(pairs), True)
            self.shell.log(
                f"已自动恢复上次标定结果（{payload.get('saved_at')}），"
                "可直接拍摄扫描帧并拼接", "success")
        else:
            self.shell.log(
                f"标定结果已恢复但无法进入扫描阶段: {msg_scan}", "warn")

    def _on_turntable_visualize_calibration(self):
        from .turntable_calibration_inspector import open_inspector
        open_inspector(self)

    def _on_multi_visualize_calibration(self):
        from copy import deepcopy
        from .calibration_inspector import CalibrationInspector, load_calibration_clouds

        if not self.can_change_workspace():
            self.shell.log('请先等待当前任务完成，再查看标定可视化。', 'warn')
            return
        pairs = {key: deepcopy(value) for key, value in self.calibration_engine.pair_results.items()
                 if value.get('success')}
        if not pairs:
            self.shell.log('尚无标定结果，请先计算外参或打开标定会话。', 'warn')
            return
        previous = getattr(self, '_calibration_inspector', None)
        if previous is not None and previous.active:
            previous.raise_()
            previous.activateWindow()
            return
        from core.multi_camera_topology import calibration_paths
        dialog = CalibrationInspector(pairs, self.shell, topology=self.calibration_engine.topology,
                                      paths=calibration_paths(self.calibration_engine))
        self._calibration_inspector = dialog
        paths = {cid: frame.offline_pointmap_path
                 for cid, frame in self.fixed_workflow.frames_calib.items()
                 if any(cid in pair for pair in pairs)}
        dialog.open()

        def done(result, error):
            if not dialog.active:
                return
            if error:
                dialog.set_clouds({}, [f'读取失败：{error}'])
            else:
                dialog.set_clouds(*result)

        self._run_background(lambda: load_calibration_clouds(paths), done,
                             name='calibration_inspection')

    def _sync_multi_topology(self):
        from core.multi_camera_topology import calibration_paths
        ws = self.shell.workspace_multi()
        ws.set_calibration_topology(self.calibration_engine.topology)
        paths = calibration_paths(self.calibration_engine)
        routes = [' → '.join(path) for cid, path in sorted(paths.items())
                  if cid != self.calibration_engine.reference_id]
        missing = set(self.calibration_engine.required_cameras) - paths.keys()
        routes.extend(cid + ' → 无合格路径' for cid in sorted(missing))
        ws._path_summary.setText('\n'.join(routes))

    def _on_multi_topology_changed(self, topology):
        if not self.can_change_workspace():
            self.shell.log('请等待当前任务完成，再切换标定方式。', 'warn')
            return
        if topology == self.calibration_engine.topology:
            self._sync_multi_topology()
            return
        self.fixed_workflow.set_topology(topology)
        ws = self.shell.workspace_multi()
        ws.clear_calibration_results()
        ws.viewer().clear_all()
        frames = self.fixed_workflow.frames_calib
        ws.set_state('detected' if len(frames) >= 2 and all(len(f.markers) >= 3 for f in frames.values())
                     else 'captured' if frames else 'connected' if ws._devices else 'idle')
        self._sync_multi_topology()
        self.shell.set_dirty(True)

    def _on_multi_calibrate(self):
        """计算外参。"""
        if self.shell._presentation == 'industrial' and not self.recognition.ensure('multi_cam',
                [frame.database_id for frame in self.fixed_workflow.frames_calib.values()], self._on_multi_calibrate):
            return
        self.shell.show_loading("正在计算外参...")
        def _work():
            ok, msg = self.fixed_workflow.calibrate()
            clouds = {}
            if ok and self.offline_preview:
                import copy
                ref = self.fixed_workflow.reference_id
                for cid, cloud in self._offline_clouds.items():
                    clouds[cid] = copy.deepcopy(cloud)
                    clouds[cid].transform(self.calibration_engine.get_transform(cid, ref))
            return ok, msg, _pairs_from_engine(self.calibration_engine), clouds
        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"标定异常: {error}", "error")
                return
            ok, msg, pairs, clouds = result
            score = _score_from_pairs(pairs)
            ws = self.shell.workspace_multi()
            # 设置参考相机，viewer 中参考相机显示为白色
            ws.viewer().set_reference(self.calibration_engine.reference_id)
            ws.on_calibrate_done(pairs, score, ok)
            self._sync_multi_topology()
            self.shell.set_dirty(True)
            if ok:
                ok_scan, msg_scan = self.fixed_workflow.start_scanning()
                if ok_scan:
                    if self.offline_preview:
                        from dataclasses import replace
                        for frame in self.fixed_workflow.frames_calib.values():
                            self.fixed_workflow.add_scan_frame(replace(frame, kind='scan'))
                        for cid, cloud in clouds.items():
                            ws.viewer().set_pointcloud(cid, cloud)
                    ws.set_state("locked")
                    self.shell.log(f"{msg} | {msg_scan}", "success")
                    self._autosave_calibration()
                else:
                    ws.set_state("calibrated")
                    self.shell.log(f"标定完成但无法进入扫描: {msg_scan}", "warn")
            else:
                ws.set_state("calibrated")
                self.shell.log(f"标定质量不达标: {msg}", "warn")
            self.shell._refresh_statusbar()
        self._run_background(_work, _done)

    def _on_multi_save_extrinsics(self):
        """保存外参。"""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self.shell, "保存外参", "calibration.json", "JSON 文件 (*.json)")
        if path:
            ok, msg = self.fixed_workflow.save_calibration(path)
            self.shell.log(msg, "success" if ok else "error")

    def _on_multi_load_extrinsics(self):
        """加载外参并直接进入扫描阶段。"""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self.shell, "加载外参", "", "JSON 文件 (*.json)")
        if not path:
            return
        ok, msg = self.fixed_workflow.load_calibration(path)
        self.shell.log(msg, "success" if ok else "error")
        if not ok:
            QMessageBox.warning(self.shell, "加载外参失败", msg)
            return

        ws = self.shell.workspace_multi()
        ref_id = self.fixed_workflow.reference_id
        ws.viewer().set_reference(ref_id)

        # 回填标定结果表格，使用户知道加载了哪些 pair
        pairs = _pairs_from_engine(self.calibration_engine)
        score = _score_from_pairs(pairs)
        ws.on_calibrate_done(pairs, score, quality_passed=True)
        self._sync_multi_topology()

        ok_scan, msg_scan = self.fixed_workflow.start_scanning()
        if ok_scan:
            ws.set_state("locked")
            self.shell.set_dirty(True)
            self.shell.log(f"外参已加载并进入扫描阶段: {msg_scan}", "success")
            self._autosave_calibration()
        else:
            ws.set_state("calibrated")
            self.shell.set_dirty(True)
            self.shell.log(f"外参已加载但无法进入扫描: {msg_scan}", "warn")

    def _on_multi_capture_scan(self):
        """拍摄扫描帧。"""
        preview_cam = self._pause_2d_preview()
        active_cards = self._pause_card_preview()
        self.shell.show_loading("正在拍摄扫描帧...")
        def _work():
            return self.camera_manager.capture_all(sync=True)
        def _done(frames, error):
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            self._resume_card_preview(active_cards)
            if error:
                self.shell.log(f"扫描拍摄失败: {error}", "error")
                return
            ws = self.shell.workspace_multi()
            all_ok = True
            for cid, frame in frames.items():
                ok, msg = self.fixed_workflow.add_scan_frame(frame)
                if ok:
                    ws.camera_grid().set_frame(cid, frame)
                    ws.camera_grid().set_frame_kind(cid, "扫描帧")
                else:
                    all_ok = False
                    self.shell.log(f"添加扫描帧失败 ({cid}): {msg}", "warn")
            if all_ok:
                self.shell.set_dirty(True)
                self.shell.log(f"扫描帧拍摄完成: {len(frames)} 台相机", "success")
            else:
                self.shell.log("部分扫描帧未加入工作流", "warn")
        self._run_background(_work, _done)

    def _on_multi_stitch_save(self):
        """拼接并保存。"""
        if self.shell._presentation == 'industrial':
            return self.stitching.execute()
        # 暂停实时预览/卡片预览：拼接 worker 与预览采集共享 SDK 全局锁，
        # 暂停可避免预览周期性地阻塞拼接（与批量扫描流程保持一致）
        preview_cam = self._pause_2d_preview()
        active_cards = self._pause_card_preview()
        self.shell.show_loading("正在拼接点云...")
        def _work():
            ok, msg, merged = self.fixed_workflow.stitch()
            return ok, msg, merged
        def _done(result, error):
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            self._resume_card_preview(active_cards)
            if error:
                self.shell.log(f"拼接异常: {error}", "error")
                return
            ok, msg, merged = result
            if ok and merged is not None:
                # 更新 3D 查看器
                ws = self.shell.workspace_multi()
                ws.viewer().set_pointcloud_merged(merged)
                self.shell.log(f"拼接完成: {len(merged.points)} 点", "success")
                # 在主线程弹窗保存
                from PySide6.QtWidgets import QFileDialog
                path, _ = QFileDialog.getSaveFileName(
                    self.shell, "保存点云", "merged.ply", "PLY 文件 (*.ply)")
                if path:
                    if write_point_cloud_atomic(path, merged):
                        logger.info(f"[拼接保存点云] 已完成: {path}")
                        self.shell.log(f"点云已保存: {path}", "success")
                    else:
                        self.shell.log(f"点云保存失败（详见日志）: {path}", "error")
            else:
                self.shell.log(f"拼接失败: {msg}", "error")
        self._run_background(_work, _done, must_finish=True, name="拼接保存点云")

    def _on_multi_batch_scan(self, n: int):
        """批量拼接保存：连续拍摄 n 次扫描帧并拼接保存。"""
        preview_cam = self._pause_2d_preview()
        active_cards = self._pause_card_preview()
        self.shell.show_loading(f"批量扫描拼接 ({n} 次)...")

        def _work():
            saved_paths = []
            for i in range(n):
                frames = self.camera_manager.capture_all(sync=True)
                if not frames:
                    return False, f"第 {i+1}/{n} 次拍摄失败：无已连接相机", saved_paths
                for cid, frame in frames.items():
                    ok, msg = self.fixed_workflow.add_scan_frame(frame)
                    if not ok:
                        return False, f"第 {i+1}/{n} 次添加扫描帧失败 ({cid}): {msg}", saved_paths
                ok, msg, merged = self.fixed_workflow.stitch()
                if not ok or merged is None:
                    return False, f"第 {i+1}/{n} 次拼接失败: {msg}", saved_paths
                path = os.path.join(
                    os.path.abspath("offline_data"),
                    f"batch_scan_{i+1:03d}.ply")
                os.makedirs(os.path.dirname(path), exist_ok=True)
                if not write_point_cloud_atomic(path, merged):
                    return False, f"第 {i+1}/{n} 次点云写盘失败（详见日志）", saved_paths
                saved_paths.append(path)
            # 1.0.12 终态日志写进 worker 内部
            logger.info(f"[批量扫描保存] 已完成 {len(saved_paths)} 帧: offline_data")
            return True, f"批量扫描完成，共保存 {len(saved_paths)} 帧", saved_paths

        def _done(result, error):
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            self._resume_card_preview(active_cards)
            if error:
                self.shell.log(f"批量扫描异常: {error}", "error")
                return
            ok, msg, paths = result
            if ok:
                self.shell.set_dirty(True)
            self.shell.log(msg, "success" if ok else "error")
            if paths:
                self.shell.log(f"保存路径: {paths[0]} 等", "info")

        self._run_background(_work, _done, must_finish=True, name="批量扫描保存")

    def _on_multi_reference_changed(self, camera_id: str, *, calibration_frames=None):
        """参考相机变更。

        若已标定/扫描阶段切换参考相机，历史标定/扫描数据会失效，需要重置
        工作流并清空 UI 结果。离线预览或设备重连提供已有标定输入时，
        保留输入供重新求解；普通在线参考相机切换仍要求重新拍摄。
        """
        ws = self.shell.workspace_multi()
        if self.offline_preview or calibration_frames:
            frames = dict(calibration_frames or self.fixed_workflow.frames_calib)
            if camera_id not in frames and frames:
                camera_id = next(iter(frames))
            self.fixed_workflow.reset()
            self.fixed_workflow.start_calibration(camera_id)
            for frame in frames.values():
                self.fixed_workflow.add_calibration_frame(frame)
            ws.clear_calibration_results()
            for cid, cloud in self._offline_clouds.items():
                ws.viewer().set_pointcloud(cid, cloud)
            ready = len(frames) >= 2 and all(len(f.markers) >= 3 for f in frames.values())
            ws.set_state('detected' if ready else 'captured')
            if calibration_frames:
                self.shell.log(f'设备已连接，保留 {len(frames)} 路标定帧，'
                               + ('可直接计算外参。' if ready else '请先检测标记再计算外参。'), 'info')
            ws.viewer().set_reference(camera_id)
            self.shell._refresh_statusbar()
            return
        state = self.fixed_workflow.get_state()
        if state in (self.fixed_workflow.STATE_CALIBRATING,
                     self.fixed_workflow.STATE_CALIBRATED,
                     self.fixed_workflow.STATE_SCANNING):
            self.fixed_workflow.reset()
            ok, msg = self.fixed_workflow.start_calibration(camera_id)
            if not ok:
                self.shell.log(f"切换参考相机失败: {msg}", "error")
                return
            ws.clear_calibration_results()
            ws.viewer().clear_all()
            ws.set_state("connected")
            self.shell.log(
                f"参考相机已切换为 {camera_id}，历史标定/扫描数据已清空，"
                "请重新拍摄标定帧", "info")
        else:
            self.shell.log(f"参考相机: {camera_id}", "info")
        self.calibration_engine.reference_id = camera_id
        ws.viewer().set_reference(camera_id)

    def _on_multi_step_back(self, index: int):
        """步骤回退。"""
        self.shell.log(f"步骤回退到: {index}", "info")
        # TODO: 根据步骤索引重置工作流状态

    def _on_card_preview_toggled(self, camera_id: str, enabled: bool):
        """单相机卡片 2D 预览开关。多卡同时预览时自动降频以减轻 SDK 负担。"""
        if enabled:
            if not self.camera_manager.is_connected(camera_id):
                self.shell.log(f"相机 {camera_id} 未连接，无法预览", "warn")
                self._set_card_preview_checked(camera_id, False)
                return
            self._card_preview_active.add(camera_id)
            # 多卡预览时自动降频：>2 卡 → 5fps，否则 10fps
            interval = 200 if len(self._card_preview_active) > 2 else 100
            if not self._card_preview_timer.isActive():
                self._card_preview_timer.start(interval)
            elif self._card_preview_timer.interval() != interval:
                self._card_preview_timer.setInterval(interval)
            self.shell.log(f"开始 2D 预览: {camera_id}", "info")
        else:
            self._card_preview_active.discard(camera_id)
            if not self._card_preview_active:
                self._card_preview_timer.stop()
            else:
                interval = 200 if len(self._card_preview_active) > 2 else 100
                self._card_preview_timer.setInterval(interval)
            self.shell.log(f"停止 2D 预览: {camera_id}", "info")

    def _on_card_preview_tick(self):
        """刷新所有处于 2D 预览状态的相机卡片。"""
        ws = self.shell.workspace_multi()
        for camera_id in list(self._card_preview_active):
            try:
                if not self.camera_manager.is_connected(camera_id):
                    self._card_preview_active.discard(camera_id)
                    self._set_card_preview_checked(camera_id, False)
                    continue
                frame = self.camera_manager.capture_2d_preview(camera_id)
                if frame is not None and frame.image_np is not None:
                    ws.camera_grid().set_frame(camera_id, frame)
            except Exception as e:
                logger.warning(f"2D 预览刷新异常 ({camera_id}): {e}")
        if not self._card_preview_active:
            self._card_preview_timer.stop()

    def _set_card_preview_checked(self, camera_id: str, checked: bool):
        """同步卡片上 2D 预览按钮的勾选状态。"""
        ws = self.shell.workspace_multi()
        card = ws.camera_grid().card(camera_id)
        if card is not None:
            card.set_preview_checked(checked)
        ws._sync_scan_preview()

    def _pause_card_preview(self) -> Set[str]:
        """暂停所有卡片 2D 预览，返回之前处于预览状态的 camera_id 集合。"""
        active = set(self._card_preview_active)
        if active:
            self._card_preview_timer.stop()
            self._card_preview_active.clear()
            for cid in active:
                self._set_card_preview_checked(cid, False)
            logger.info(f"已暂停卡片 2D 预览: {active}")
        return active

    def _resume_card_preview(self, active: Set[str]):
        """恢复之前暂停的卡片 2D 预览。"""
        if not active:
            return
        for cid in active:
            if self.camera_manager.is_connected(cid):
                self._card_preview_active.add(cid)
                self._set_card_preview_checked(cid, True)
        if self._card_preview_active:
            interval = 200 if len(self._card_preview_active) > 2 else 100
            self._card_preview_timer.start(interval)
            logger.info(f"已恢复卡片 2D 预览: {self._card_preview_active}")

    def _on_card_capture(self, camera_id: str):
        """单相机卡片 3D 拍摄。

        注意：RVC SDK 同一相机句柄上 2D 预览与 3D 拍摄互斥，拍摄前必须
        停止所有 2D 预览（卡片预览定时器 + 移动工作站预览定时器），拍摄
        结束后恢复其他相机的预览。
        """
        if not self.camera_manager.is_connected(camera_id):
            self.shell.log(f"拍摄失败: 相机 {camera_id} 未连接", "warn")
            return

        # 1. 停止卡片 2D 预览
        was_card_preview_active = camera_id in self._card_preview_active
        if was_card_preview_active:
            self._card_preview_active.discard(camera_id)
            self._set_card_preview_checked(camera_id, False)
        # 即使本机未开预览，也暂停整个卡片预览定时器，防止并发 2D/3D 冲突
        card_timer_was_running = self._card_preview_timer.isActive()
        if card_timer_was_running:
            self._card_preview_timer.stop()

        # 2. 暂停移动工作站实时取景（若正在运行）
        mobile_preview_cam = self._pause_2d_preview()

        self.shell.show_loading(f"正在拍摄 {camera_id}...")

        def _work():
            frame = self.camera_manager.capture(camera_id)
            if self.shell._presentation == 'industrial':
                return frame, frame.load_pointcloud_o3d() if frame is not None else None
            return frame

        def _done(frame, error):
            cloud = None
            if isinstance(frame, tuple):
                frame, cloud = frame
            self.shell.hide_loading()
            # 恢复移动工作站预览
            self._resume_2d_preview(mobile_preview_cam)
            # 失败路径：恢复本机卡片预览勾选
            if error or frame is None:
                if was_card_preview_active:
                    self._card_preview_active.add(camera_id)
                    self._set_card_preview_checked(camera_id, True)
            # 恢复其他相机的卡片预览定时器
            if self._card_preview_active and card_timer_was_running:
                self._card_preview_timer.start(200 if len(self._card_preview_active) > 2 else 100)

            if error:
                self.shell.log(f"拍摄失败 ({camera_id}): {error}", "error")
                return
            if frame is None:
                self.shell.log(f"拍摄失败 ({camera_id}): 无数据", "warn")
                return
            ws = self.shell.workspace_multi()
            ok, msg = self.fixed_workflow.add_calibration_frame(frame)
            if not ok:
                self.shell.log(f"添加标定帧失败 ({camera_id}): {msg}", "warn")
            ws.camera_grid().set_frame(camera_id, frame)
            ws.camera_grid().set_frame_kind(camera_id, "标定帧")
            # 把单相机点云刷新到 3D 查看器（叠加显示）
            try:
                pcd = cloud if self.shell._presentation == 'industrial' else frame.load_pointcloud_o3d()
                if pcd is not None and len(pcd.points) > 0:
                    pts_arr = np.asarray(pcd.points)
                    n_total = len(pts_arr)
                    n_invalid = int((~np.isfinite(pts_arr).all(axis=1)).sum())
                    ws.viewer().set_pointcloud(camera_id, pcd)
                    self.shell.log(
                        f"点云已加载 ({camera_id}): {n_total} 点"
                        f"{f' (含 {n_invalid} 个无效点)' if n_invalid else ''}",
                        "info")
                else:
                    self.shell.log(f"点云为空 ({camera_id})", "warn")
            except Exception as e:
                self.shell.log(f"加载点云失败 ({camera_id}): {e}", "warn")
            # 如果已有标定帧，允许继续检测/计算，但不自动推进状态
            if ws.current_state() == "connected":
                ws.set_state("captured")
            self.shell.set_dirty(True)
            self.shell.log(f"拍摄完成 ({camera_id})", "success")

        self._run_background(_work, _done)

    def _on_card_detect(self, camera_id: str):
        """单相机卡片检测标记物。"""
        ws = self.shell.workspace_multi()
        card = ws.camera_grid().card(camera_id)
        if card is None:
            return
        frame = card.current_frame()

        # 若当前只有 2D 预览帧（无点云），先拍摄 3D 帧再检测
        if frame is None or not frame.has_pointcloud:
            self.shell.log(f"{camera_id} 无 3D 帧，先执行 3D 拍摄再检测", "info")
            self._capture_then_detect(camera_id)
            return

        self._run_detect_on_frame(camera_id, frame)

    def _capture_then_detect(self, camera_id: str):
        """先 3D 拍摄再对单相机卡片执行检测。"""
        if not self.camera_manager.is_connected(camera_id):
            self.shell.log(f"检测失败: 相机 {camera_id} 未连接", "warn")
            return
        # 停止该卡 2D 预览
        if camera_id in self._card_preview_active:
            self._card_preview_active.discard(camera_id)
            self._set_card_preview_checked(camera_id, False)
            if not self._card_preview_active:
                self._card_preview_timer.stop()

        self.shell.show_loading(f"正在拍摄并检测 {camera_id}...")

        def _work():
            return self.camera_manager.capture(camera_id)

        def _done(frame, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"拍摄失败 ({camera_id}): {error}", "error")
                return
            if frame is None:
                self.shell.log(f"拍摄失败 ({camera_id}): 无数据", "warn")
                return
            ws = self.shell.workspace_multi()
            ok, msg = self.fixed_workflow.add_calibration_frame(frame)
            if not ok:
                self.shell.log(f"添加标定帧失败 ({camera_id}): {msg}", "warn")
            ws.camera_grid().set_frame(camera_id, frame)
            ws.camera_grid().set_frame_kind(camera_id, "标定帧")
            if ws.current_state() == "connected":
                ws.set_state("captured")
            self.shell.set_dirty(True)
            self._run_detect_on_frame(camera_id, frame)

        self._run_background(_work, _done)

    def _run_detect_on_frame(self, camera_id: str, frame: FrameData):
        """对已有 3D 帧执行标记物检测并回填 UI。"""
        if self.shell._presentation == 'industrial' and self.recognition.enabled and frame.database_id:
            self.recognition.retry('multi_cam', [frame.database_id])
            return
        ws = self.shell.workspace_multi()
        method = ws.current_detect_method()
        self.marker_detector.set_marker_type(self._map_detect_method(method))

        self.shell.show_loading(f"正在检测 {camera_id}...")

        def _work():
            markers_all = self.marker_detector.detect_3d(
                frame.image_np,
                pointmap=frame.pointmap,
                rvc_image=frame.rvc_image,
                offline_ply_path=frame.offline_pointmap_path,
                include_invalid=True,
            )
            return markers_all

        def _done(markers_all, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"检测失败 ({camera_id}): {error}", "error")
                return
            frame.markers_all = markers_all
            markers = [m for m in markers_all if m.get('valid_3d', True)]
            frame.markers = markers
            count = len(markers)
            grid = ws.camera_grid()
            grid.set_frame(camera_id, frame)
            grid.set_marker_count(camera_id, count)
            grid.set_covis_status(camera_id, count > 0)
            n_invalid = len(markers_all) - count
            suffix = f"，{n_invalid} 个 3D 无效（红圈）" if n_invalid else ""
            self.shell.log(f"检测完成 ({camera_id}): {count} 个标记{suffix}",
                           "success")

        self._run_background(_work, _done)

    def _map_detect_method(self, method: str) -> str:
        """把 UI 检测方式映射到 MarkerDetector 内部类型。"""
        if method == "calib_board":
            return "asymmetric_grid"
        return method or "coded_circle"

    # ------------------------------------------------------------------
    # 模式 B（单相机移动链式）
    # ------------------------------------------------------------------
    def _on_mobile_preview_toggled(self, enabled: bool):
        """实时取景开关。"""
        if not enabled:
            self._stop_preview_thread(clear_frame=False)
            self.shell.log("已停止实时取景", "info")
            return
        # 找到已连接的物理相机（模式 B 只有一台）
        connected = self.camera_manager.get_connected_ids()
        if not connected:
            self.shell.log("没有已连接相机，无法取景", "warn")
            self.shell.workspace_mobile().set_preview_enabled(False)
            return
        self._start_preview_thread(connected[0])

    def _start_preview_thread(self, camera_id: str):
        """启动实时取景采集线程（已在运行则先停止旧线程）。"""
        self._stop_preview_thread()
        self._preview_camera_id = camera_id
        # 取景瞄准不需要 10fps；5fps 把 SDK Image 高频建/销的暴露量减半，
        # 这是当前堆损坏嫌疑循环的主要缓解手段（间隔可调回 100ms）
        self._preview_thread = PreviewCaptureThread(
            self.camera_manager, camera_id, interval_ms=200, parent=self)
        self._preview_thread.frame_ready.connect(self._on_preview_frame)
        self._preview_thread.start()
        self.shell.log(f"开始实时取景: {camera_id}", "info")

    def _stop_preview_thread(self, *, clear_frame=True):
        """Stop acquisition; user stop/pause retains the last displayed frame."""
        if self._preview_thread is not None:
            self._preview_thread.stop()  # 等待在飞采集完成（带超时）
            self._preview_thread = None
        self._preview_camera_id = None
        if clear_frame:
            self.shell.workspace_mobile().live_view().set_frame(None)

    def _on_preview_frame(self, pixmap, *, source=None):
        """预览帧到达（UI 线程）：仅做显示，采集/转换已在线程内完成。"""
        source = source or self.sender()
        if self._preview_thread is None or (source is not None and source is not self._preview_thread):
            return
        self.shell.workspace_mobile().live_view().set_frame(pixmap)

    def _pause_2d_preview(self) -> Optional[str]:
        """暂停持续 2D 预览，返回之前正在预览的 camera_id（如无则 None）。

        RVC SDK 不允许同一 X2/X1 句柄上并发执行 Capture2D 与 Capture（3D）：
        M2600C 等三目相机的彩色 Extra 相机处于 2D 预览流时，直接调用 3D 拍摄
        会导致驱动状态冲突/崩溃。所有 3D 拍摄入口必须先调用本方法。
        """
        if self._preview_thread is None:
            return None
        camera_id = self._preview_camera_id
        self._stop_preview_thread(clear_frame=False)
        # 同步 UI 按钮状态（避免用户以为预览仍在运行）
        ws = self.shell.workspace_mobile()
        if ws.is_preview_enabled():
            ws.set_preview_enabled(False)
        logger.info(f"已暂停 2D 预览（准备 3D 拍摄）: {camera_id}")
        return camera_id

    def _resume_2d_preview(self, camera_id: Optional[str]):
        """恢复之前暂停的 2D 预览。"""
        if camera_id is None:
            return
        connected = self.camera_manager.get_connected_ids()
        if camera_id not in connected:
            return
        ws = self.shell.workspace_mobile()
        self._start_preview_thread(camera_id)
        if not ws.is_preview_enabled():
            ws.set_preview_enabled(True)
        logger.info(f"已恢复 2D 预览: {camera_id}")

    def _update_mobile_live_view(self, station_id: str, accepted=None):
        """把指定机位的 2D 图像与检测标记刷新到 LiveViewPanel。"""
        sm = self.mobile_workflow.station_manager
        if sm is None:
            return
        frame = sm.get_frame(station_id)
        if frame is None or frame.image_np is None:
            return
        pixmap = numpy_to_qpixmap(frame.image_np)
        if pixmap is None:
            return
        ws = self.shell.workspace_mobile()
        ws.live_view().set_frame(pixmap)
        # 标记叠加（归一化坐标；markers_all 含 3D 无效标记 → 红圈）
        h, w = frame.image_np.shape[:2]
        if h > 0 and w > 0:
            markers = [
                (m.get('x_2d', m.get('x', 0)) / w,
                 m.get('y_2d', m.get('y', 0)) / h,
                 int(m.get('code', 0)),
                 bool(m.get('valid_3d', True)))
                for m in (frame.markers_all or frame.markers)
            ]
            ws.live_view().set_detection_overlay(markers)
        self._set_mobile_marker_context(frame, accepted)

    def _set_mobile_marker_context(self, frame, accepted=None):
        manager = self.mobile_workflow.station_manager
        reference = None
        if manager is not None:
            ids = manager.get_station_ids()
            index = next((i for i, key in enumerate(ids) if manager.get_frame(key) is frame), len(ids))
            if index > 0:
                reference = manager.get_frame(ids[index-1])
        self.shell.workspace_mobile().live_view().set_marker_context(frame, reference, accepted)

    def _refresh_mobile_frame_to_ui(self, frame: FrameData, accepted=None):
        """把任意 FrameData 的 2D 图像与 3D 点云刷新到模式 B UI。

        用于配准失败帧：该帧已从 station_manager 删除，但 evaluation 中仍附带，
        需要直接由 frame 刷新，而不是通过 station_id 查询。
        """
        if frame is None or frame.image_np is None:
            return
        ws = self.shell.workspace_mobile()

        # 2D 画面
        pixmap = numpy_to_qpixmap(frame.image_np)
        if pixmap is not None:
            ws.live_view().set_frame(pixmap)
        # 标记叠加（归一化坐标；markers_all 含 3D 无效标记 → 红圈）
        h, w = frame.image_np.shape[:2]
        if h > 0 and w > 0:
            markers = [
                (m.get('x_2d', m.get('x', 0)) / w,
                 m.get('y_2d', m.get('y', 0)) / h,
                 int(m.get('code', 0)),
                 bool(m.get('valid_3d', True)))
                for m in (frame.markers_all or frame.markers)
            ]
            ws.live_view().set_detection_overlay(markers)
        self._set_mobile_marker_context(frame, accepted)

        # 3D 点云（单帧预览）
        try:
            pcd = frame.load_pointcloud_o3d()
            if pcd is not None and len(pcd.points) > 0:
                ws.viewer().set_pointcloud_merged(pcd)
                self.shell.log(
                    f"单帧点云已加载: {len(pcd.points)} 点", "info")
        except Exception as e:
            self.shell.log(f"加载单帧点云失败: {e}", "warn")

    def _refresh_mobile_live_view_to_latest(self):
        """刷新 LiveViewPanel 为最新机位（撤销/删除后调用）。"""
        sm = self.mobile_workflow.station_manager
        if sm is None:
            return
        station_ids = sm.get_station_ids()
        if not station_ids:
            ws = self.shell.workspace_mobile()
            ws.live_view().set_frame(None)
            ws.live_view().set_detection_overlay([])
            ws.live_view().set_marker_context(None)
            return
        self._update_mobile_live_view(station_ids[-1])

    def _station_id_from_timeline_index(self, index: int) -> Tuple[Optional[str], int]:
        """把时间线索引映射为后端真实的 station_id。

        index 为 1-based 时间线索引；-1 表示当前/最新机位。
        返回 (station_id, timeline_index)。station_id 为 None 表示不存在。
        """
        ws = self.shell.workspace_mobile()
        stations = self.mobile_workflow.get_station_list()
        n = len(stations)
        if n == 0:
            return None, index
        if index == -1:
            timeline_index = n
        elif 1 <= index <= n:
            timeline_index = index
        else:
            return None, index
        # 优先用时间线节点上保存的 backend_ref，失败再按列表顺序回退
        station_id = ws.get_station_id(timeline_index)
        if station_id is None and stations:
            station_id = stations[timeline_index - 1].get('station_id')
        return station_id, timeline_index

    def _on_mobile_capture_station(self):
        """拍摄机位（自动配准）。"""
        if self.shell._presentation == 'industrial':
            return self.stitching.capture_mobile()
        preview_cam = self._pause_2d_preview()
        ws = self.shell.workspace_mobile()
        ws.set_state("capturing")
        self.shell.show_loading("正在拍摄机位...")
        def _work():
            ok, msg, evaluation = self.mobile_workflow.capture_station()
            # 拼接合并是耗时操作，放到后台线程执行
            merged = None
            if ok:
                merged = self.mobile_workflow.get_merged_pointcloud()
            return ok, msg, evaluation, merged

        def _done(result, error):
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            if error:
                ws.set_state("chaining")
                self.shell.log(f"拍摄异常: {error}", "error")
                return
            ok, msg, evaluation, merged = result
            if evaluation:
                ws.on_evaluation_done(
                    evaluation.get('common_markers', 0),
                    evaluation.get('inlier_ratio', 0.0),
                    evaluation.get('rms_mm'),
                    'ok' if evaluation.get('success') else 'fail',
                    evaluation.get('suggestion', ''),
                    backend_ref=evaluation.get('station_id'),
                )
                # 无论配准成败，都先把当前帧的 2D/3D 数据显示出来
                # （失败帧已从 station_manager 删除， evaluation 中附带 frame）
                frame = evaluation.get('frame')
                station_id = evaluation.get('station_id')
                if frame is not None:
                    self._refresh_mobile_frame_to_ui(frame, accepted=ok)
                elif station_id:
                    self._update_mobile_live_view(station_id, accepted=ok)
            else:
                ws.set_state("chaining")
            if ok:
                self.shell.log(f"机位配准成功: {msg}", "success")
                self.shell.set_dirty(True)
                # 刷新 3D 拼接（已在后台计算好）
                if merged is not None:
                    ws.viewer().set_pointcloud_merged(merged)
            else:
                self.shell.log(f"机位配准失败: {msg}", "warn")
        self._run_background(_work, _done)

    def _on_mobile_undo(self):
        """撤销上一机位（合并点云在后台计算）。"""
        if self.shell._presentation == 'industrial':
            return self.stitching.undo_mobile()
        ws = self.shell.workspace_mobile()
        self.shell.show_loading("正在撤销...")

        def _work():
            ok, msg = self.mobile_workflow.undo_last_station()
            merged = None
            if ok:
                merged = self.mobile_workflow.get_merged_pointcloud()
            return ok, msg, merged

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"撤销异常: {error}", "error")
                return
            ok, msg, merged = result
            self.shell.log(msg, "info" if ok else "warn")
            if ok:
                self.shell.set_dirty(True)
                ws.on_undo_done()
                self._refresh_mobile_live_view_to_latest()
                if merged is None:
                    ws.viewer().clear_all()
                else:
                    ws.viewer().set_pointcloud_merged(merged)

        self._run_background(_work, _done)

    def _on_mobile_recapture(self, index: int):
        """重拍指定机位（index 为时间线索引，-1 表示当前/最新机位）。"""
        if self.shell._presentation == 'industrial':
            return self.stitching.recapture_mobile()
        preview_cam = self._pause_2d_preview()
        ws = self.shell.workspace_mobile()

        # 时间线索引 → 后端机位 ID（考虑拍废删除导致的错位）
        station_id, timeline_index = self._station_id_from_timeline_index(index)
        if station_id is None:
            self._resume_2d_preview(preview_cam)
            self.shell.log("重拍失败: 指定机位不存在", "warn")
            return

        # 若目标为已固定的参考机位，先询问是否重置整条链并重新拍摄
        reset_for_reference = False
        if (self.mobile_workflow._chain_stitcher is not None and
                station_id == self.mobile_workflow._chain_stitcher._reference_id and
                len(self.mobile_workflow._chain_stitcher.nodes) > 1):
            reply = QMessageBox.question(
                self.shell, "重拍参考机位",
                "参考机位已固定，重拍将清空整条链并回到初始状态。\n是否继续？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No)
            if reply != QMessageBox.Yes:
                self._resume_2d_preview(preview_cam)
                self.shell.log("已取消重拍参考机位", "info")
                return
            ok, msg = self.mobile_workflow.reset_chain()
            if not ok:
                self._resume_2d_preview(preview_cam)
                self.shell.log(f"重拍失败: {msg}", "warn")
                return
            ws.reset_session()
            reset_for_reference = True
            timeline_index = 1  # 重置后拍摄的是新的 #1

        ws.set_state("capturing")
        self.shell.show_loading(f"正在重拍 #{timeline_index}...")

        def _work():
            if reset_for_reference:
                ok, msg, evaluation = self.mobile_workflow.capture_station()
            else:
                ok, msg, evaluation = self.mobile_workflow.recapture_station(station_id)
            # 拼接合并是耗时操作，放到后台线程执行
            merged = None
            if ok:
                merged = self.mobile_workflow.get_merged_pointcloud()
            return ok, msg, evaluation, merged

        def _done(result, error):
            self.shell.hide_loading()
            self._resume_2d_preview(preview_cam)
            if error:
                ws.set_state("chaining")
                self.shell.log(f"重拍异常: {error}", "error")
                return
            ok, msg, evaluation, merged = result
            if evaluation:
                level = 'ok' if evaluation.get('success') else 'fail'
                if reset_for_reference:
                    # 重置后按新机位入链
                    ws.on_evaluation_done(
                        evaluation.get('common_markers', 0),
                        evaluation.get('inlier_ratio', 0.0),
                        evaluation.get('rms_mm'),
                        level,
                        evaluation.get('suggestion', ''),
                        backend_ref=evaluation.get('station_id'),
                    )
                else:
                    # 非参考机位重拍会删除旧机位并在链尾插入新机位，
                    # 直接用后端机位列表重建时间线，避免索引错位
                    ws.set_stations(self.mobile_workflow.get_station_evaluations())
                    ws.set_evaluation(
                        evaluation.get('common_markers', 0),
                        evaluation.get('inlier_ratio', 0.0),
                        evaluation.get('rms_mm'),
                        level,
                        evaluation.get('suggestion', ''),
                    )
                # 无论重拍成败，都先刷新当前帧 2D/3D
                frame = evaluation.get('frame')
                new_station_id = evaluation.get('station_id')
                if frame is not None:
                    self._refresh_mobile_frame_to_ui(frame)
                elif new_station_id:
                    self._update_mobile_live_view(new_station_id)
            else:
                ws.set_state("chaining")
            if ok:
                self.shell.log(f"重拍成功: {msg}", "success")
                self.shell.set_dirty(True)
                # 刷新 3D 拼接（已在后台计算好）
                if merged is not None:
                    ws.viewer().set_pointcloud_merged(merged)
            else:
                self.shell.log(f"重拍失败: {msg}", "warn")

        self._run_background(_work, _done)

    def _on_mobile_delete_station(self, index: int):
        """删除指定机位（index 为时间线索引）。"""
        if self.shell._presentation == 'industrial':
            return self.stitching.delete_mobile()
        station_id, _ = self._station_id_from_timeline_index(index)
        if station_id is None:
            self.shell.log("删除失败: 指定机位不存在", "warn")
            return

        ok, msg = self.mobile_workflow.delete_station(station_id)
        # 参考机位已固定：需要二次确认是否重置整条链
        if not ok and "参考机位已固定" in msg:
            reply = QMessageBox.question(
                self.shell, "删除参考机位",
                "参考机位已固定，删除将清空整条链并回到初始状态。\n是否继续？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No)
            if reply != QMessageBox.Yes:
                self.shell.log("已取消删除参考机位", "info")
                return
            ok, msg = self.mobile_workflow.reset_chain()

        self.shell.log(msg, "success" if ok else "warn")
        if not ok:
            return
        self.shell.set_dirty(True)
        ws = self.shell.workspace_mobile()
        # 按后端当前机位列表重建时间线，避免误清整条链
        evaluations = self.mobile_workflow.get_station_evaluations()
        ws.set_stations(evaluations)
        self._refresh_mobile_live_view_to_latest()

        # 拼接合并是耗时操作，放到后台线程执行
        self.shell.show_loading("正在刷新拼接点云...")

        def _work():
            return self.mobile_workflow.get_merged_pointcloud()

        def _done(merged, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"刷新点云失败: {error}", "error")
                return
            if merged is None:
                ws.viewer().clear_all()
            else:
                ws.viewer().set_pointcloud_merged(merged)

        self._run_background(_work, _done)

    def _on_mobile_station_selected(self, index: int):
        """时间线选中机位：在 2D 实时取景区显示该机位图像。"""
        station_id, _ = self._station_id_from_timeline_index(index)
        if station_id is None:
            return
        self._update_mobile_live_view(station_id)

    def _on_mobile_optimize(self):
        """全局优化（拼接合并点云在后台计算）。"""
        self.shell.show_loading("正在全局优化...")
        def _work():
            ok, msg, before_mm, after_mm = self.mobile_workflow.optimize_global()
            # 拼接合并是耗时操作，放到后台线程执行
            merged = None
            if ok:
                merged = self.mobile_workflow.get_merged_pointcloud()
            return ok, msg, before_mm, after_mm, merged

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"优化异常: {error}", "error")
                return
            ok, msg, before_mm, after_mm, merged = result
            self.shell.log(msg, "success" if ok else "warn")
            if ok:
                self.shell.set_dirty(True)
                ws = self.shell.workspace_mobile()
                ws.on_optimize_done(before_mm, after_mm)
                # 刷新 3D 拼接（已在后台计算好）
                if merged is not None:
                    ws.viewer().set_pointcloud_merged(merged)
        self._run_background(_work, _done)

    def _on_mobile_save(self):
        """保存拼接数据：合并点云 PLY + 误差报告 JSON。"""
        export_path = None
        if self.shell._presentation == 'industrial':
            project = self.projects.projects['mobile_chain']
            default = project.save_root / (project.name + '_merged.ply')
            export_path, _ = QFileDialog.getSaveFileName(self.shell, '导出拼接点云', str(default), 'PLY 点云 (*.ply)')
            if not export_path:
                return
        self.shell.show_loading("正在保存拼接数据...")

        def _work():
            report = self.mobile_workflow.get_error_report()
            if not report:
                return False, "无机位数据可保存", None
            session_dir = os.path.dirname(os.path.abspath(export_path)) if export_path else report.get('session_dir')
            if not session_dir:
                return False, "会话目录未知，无法保存", None
            os.makedirs(session_dir, exist_ok=True)

            merged = self.mobile_workflow.get_merged_pointcloud()
            ply_path = export_path or os.path.join(session_dir, "merged.ply")
            if merged is not None:
                if not write_point_cloud_atomic(ply_path, merged):
                    return False, f"点云写盘失败（详见日志）: {ply_path}", None
            else:
                ply_path = None

            json_path = os.path.splitext(export_path)[0] + '_report.json' if export_path else os.path.join(session_dir, "error_report.json")
            if export_path:
                project = self.projects.projects['mobile_chain']
                report.update(session_dir=str(project.saved_path) if project.saved_path else None,
                              project_id=project.uid, project_name=project.name)
            write_json_atomic(json_path, report, ensure_ascii=False, indent=2)

            # 1.0.12 终态日志写进 worker 内部
            logger.info(f"[保存拼接数据] 已完成: {session_dir}")
            return True, f"会话已保存: {session_dir}", {
                "session_dir": session_dir,
                "ply_path": ply_path,
                "json_path": json_path,
            }

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"保存失败: {error}", "error")
                return
            ok, msg, paths = result
            self.shell.log(msg, "success" if ok else "warn")
            if ok and paths:
                if paths.get("ply_path"):
                    self.shell.log(f"点云: {paths['ply_path']}", "info")
                self.shell.log(f"报告: {paths['json_path']}", "info")

        self._run_background(_work, _done, must_finish=True, name="保存拼接数据")

    def _on_mobile_offline_load(self, session_dir=None):
        """离线加载单相机站位会话目录并自动拼接。"""
        from PySide6.QtWidgets import QFileDialog

        base = self.mobile_workflow.session_dir or "offline_data/stations"
        session_dir = session_dir or QFileDialog.getExistingDirectory(
            self.shell, "选择单相机会话目录", base)
        if not session_dir:
            return
        if self.shell._presentation == 'industrial':
            return self.projects.guard_switch('mobile_chain', lambda:
                self.projects.open(session_dir, 'mobile_chain', legacy=True))

        self.shell.show_loading("正在离线加载会话...")

        def _work():
            ok, msg = self.mobile_workflow.load_session_dir(session_dir)
            if not ok:
                return False, msg, None, None
            evaluations = self.mobile_workflow.get_station_evaluations()
            merged = self.mobile_workflow.get_merged_pointcloud()
            report = self.mobile_workflow.get_error_report()
            return True, msg, evaluations, (merged, report)

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"离线加载失败: {error}", "error")
                return
            ok, msg, evaluations, data = result
            self.shell.log(msg, "success" if ok else "warn")
            if not ok or not evaluations:
                return

            if self.shell._presentation == 'industrial':
                self.projects.prepare('mobile_chain')

            ws = self.shell.workspace_mobile()
            ws.reset_session()
            ws.set_stations(evaluations)
            ws.set_state("chaining" if len(evaluations) < 3 else "ready")
            self.shell.set_dirty(True)

            merged, report = data
            if merged is not None:
                ws.viewer().set_pointcloud_merged(merged)
                self.shell.log(
                    f"合并点云已显示: {len(merged.points)} 点", "info")
            if report:
                self.shell.log(
                    f"节点 {report.get('n_nodes', 0)} 边 {report.get('n_edges', 0)} "
                    f"累计误差 {report.get('cum_rms_mm', 0):.3f}mm", "info")

        self._run_background(_work, _done)

    def _on_robot_publish(self):
        if not self.can_change_workspace():
            self.shell.log('当前任务进行中，不能发布机器人拼接结果', 'warn')
            return
        workflow = self.robot_workflow
        if workflow.handeye is None or not workflow.handeye.validated:
            self.shell.log('机器人拼接结果发布被戳点门禁拦住：未 VERIFIED', 'warn')
            return
        cloud = workflow.get_merged_pointcloud()
        source_ids = [frame.database_id for frame in workflow.frames]
        if cloud is None or not source_ids or any(not uid for uid in source_ids):
            self.shell.log('没有可发布的机器人拼接结果或原始帧身份', 'warn')
            return
        database = self.projects.projects['robot_stitch'].database

        def work():
            return database.publish_result(cloud, source_ids, name='机器人基座系合并点云',
                source_transforms={uid: matrix.tolist() for uid, matrix in zip(source_ids, workflow.transforms)})

        def done(uid, error):
            if error:
                self.shell.log(f'机器人拼接结果发布失败：{error}', 'error')
                return
            self.projects.mark_changed('robot_stitch')
            self.shell.log(f'机器人基座系合并结果已写入项目 DB：{uid}', 'success')

        self._run_background(work, done, name='robot_publish')

    # ------------------------------------------------------------------
    # 主窗口
    # ------------------------------------------------------------------
    def _on_save_session(self):
        """保存当前会话（标定帧 + 扫描帧 + 外参）。"""
        if self.shell._presentation == 'industrial':
            self.projects.save()
            return
        self.shell.show_loading("正在保存会话...")

        def _work():
            if self._current_mode == LauncherDialog.MODE_MULTI_CAM:
                result = self._save_fixed_session()
            elif self._current_mode == LauncherDialog.MODE_TURNTABLE:
                result = self._save_turntable_session()
            else:
                result = self._save_mobile_session()
            # 1.0.12 终态日志写进 worker 内部：os._exit 之后这是保存是否完成的唯一证据
            if result[0]:
                logger.info(f"[保存会话] 已完成: {result[1]}")
            else:
                logger.warning(f"[保存会话] 失败: {result[1]}")
            return result

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"保存会话失败: {error}", "error")
                self.shell.session_save_finished.emit(False, str(error))
                return
            ok, msg = result
            self.shell.log(msg, "success" if ok else "warn")
            if ok:
                self.shell.set_dirty(False)
            self.shell.session_save_finished.emit(ok, msg)

        self._run_background(_work, _done, must_finish=True, name="保存会话")

    def _save_fixed_session(self) -> Tuple[bool, str]:
        """保存多相机模式会话（标定帧 + 扫描帧 + 标定结果）。"""
        session = OfflineSession()
        session.create_new("offline_data")
        # 保存标定帧
        for cid, frame in self.fixed_workflow.frames_calib.items():
            session.add_frame(cid, frame)
        # 保存扫描帧（使用递增 frame_id 避免覆盖）
        scan_frames = self.fixed_workflow.frames_scan
        if scan_frames:
            max_id = 0
            for flist in session.frames.values():
                for f in flist:
                    max_id = max(max_id, f.frame_id)
            for cid, frame in scan_frames.items():
                frame.frame_id = max_id + 1
                session.add_frame(cid, frame)
        # 保存标定结果（reference_id + pairs），打开会话时可恢复并直接进入扫描
        if self.calibration_engine.pair_results:
            session.set_meta("calibration", self.calibration_engine.to_dict())
        session.save_all()
        return True, f"会话已保存: {session.session_dir}"

    def _save_mobile_session(self) -> Tuple[bool, str]:
        """保存单相机移动拼接会话。"""
        report = self.mobile_workflow.get_error_report()
        if not report:
            return False, "无机位数据可保存"
        # StationManager 已在拍摄时存盘，这里只返回会话路径
        return True, f"移动拼接会话已保存: {report.get('session_dir', 'unknown')}"

    def _save_turntable_session(self) -> Tuple[bool, str]:
        """保存转台 360° 拼接会话（序列帧 + 标定元数据）。"""
        ws = self.shell.workspace_turntable()
        session = ws.session
        frames = session.get_all_frames()
        if not frames and not session.is_calibrated():
            return False, "无转台数据可保存（请先标定或采集）"

        offline = OfflineSession()
        offline.create_new("offline_data")
        for frame in frames:
            cam_id = getattr(frame, "camera_name", None) or "cam0"
            offline.add_frame(cam_id, frame)

        meta = {
            "mode": "turntable",
            "step_count": session.step_count(),
            "total_steps_needed": session.total_steps_needed(),
            "current_step": session.current_step,
        }
        calib = session.calib
        if calib.is_calibrated():
            meta["angle_deg"] = float(np.degrees(calib.angle_rad))
            meta["axis"] = (
                calib.axis.tolist() if calib.axis is not None else None)
            meta["center"] = (
                calib.center.tolist() if calib.center is not None else None)

        try:
            meta_path = os.path.join(offline.session_dir, "turntable_meta.json")
            write_json_atomic(meta_path, meta, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"保存转台元数据失败: {e}")

        offline.save_all()
        return True, f"转台会话已保存: {offline.session_dir}"

    def _on_open_session(self):
        """打开离线会话并加载帧。"""
        from PySide6.QtWidgets import QFileDialog
        base = str(self.projects.projects[self._current_mode].save_root) if self.shell._presentation == 'industrial' else os.path.abspath('offline_data')
        os.makedirs(base, exist_ok=True)
        path = QFileDialog.getExistingDirectory(
            self.shell, "选择会话目录", base)
        if not path:
            return
        if self.shell._presentation == 'industrial' and os.path.isfile(os.path.join(path, 'session.json')):
            mode = self._current_mode
            self.projects.guard_switch(mode, lambda: self.projects.open(path, mode))
            return
        if self.shell._presentation == 'industrial':
            mode = self._current_mode
            self.projects.guard_switch(mode, lambda: self.projects.open(path, mode, legacy=True))
            return
        self.shell.show_loading("正在加载会话...")

        def _work():
            session = OfflineSession()
            frames = session.load_session(path)
            return session, frames

        def _done(result, error):
            self.shell.hide_loading()
            if error:
                self.shell.log(f"加载会话失败: {error}", "error")
                return
            session, frames = result
            self._load_session_into_workflow(session, frames, path)

        self._run_background(_work, _done)

    def _load_session_into_workflow(self, session: OfflineSession,
                                    frames: Dict[str, List[FrameData]],
                                    path: str):
        """把加载的会话帧回填到当前工作流与 UI。"""
        if self._current_mode == LauncherDialog.MODE_MULTI_CAM:
            self._load_fixed_session(session, frames)
        elif self._current_mode == LauncherDialog.MODE_MOBILE_CHAIN:
            # 模式 B：加载会话暂不恢复时间线，仅记录
            self.shell.log(
                f"模式 B（单相机移动拼接）会话已读取 {len(frames)} 台相机数据，"
                "时间线恢复待实现", "warn")
        else:
            # 模式 C：恢复标定数据（以及可选的步进采集帧）
            ws = self.shell.workspace_turntable()
            loaded_any = False

            # 1. 恢复标定参数
            meta_path = os.path.join(path, "turntable_meta.json")
            if os.path.exists(meta_path):
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    if meta.get("axis") is not None and meta.get("angle_deg") is not None:
                        if ws.apply_loaded_calibration(meta):
                            loaded_any = True
                            self.shell.log(
                                "已从会话恢复转台标定数据，可直接步进采集/拼接",
                                "success")
                except Exception as e:
                    self.shell.log(f"读取转台会话元数据失败: {e}", "error")

            # 2. 恢复步进采集帧（如有），加载后可直接拼接
            seq_frames: List[FrameData] = []
            for _cid, flist in frames.items():
                seq_frames.extend(flist)
            seq_frames.sort(key=lambda f: f.frame_id)
            if seq_frames:
                n = ws.load_sequence_frames(seq_frames)
                loaded_any = True
                self.shell.log(f"已从会话恢复 {n} 帧步进采集数据", "success")

            if not loaded_any:
                self.shell.log(
                    "会话中没有可恢复的转台标定或帧数据", "warn")
            else:
                self.shell.set_dirty(True)

    # ------------------------------------------------------------------
    # 模式 A 会话加载
    # ------------------------------------------------------------------
    @staticmethod
    def _split_session_frames(
        frames: Dict[str, List[FrameData]],
    ) -> Tuple[Dict[str, FrameData], Dict[str, FrameData]]:
        """把会话帧按用途拆分为 {camera_id: 最新标定帧} 与 {camera_id: 最新扫描帧}。

        新会话帧带 kind 标记（"calib"/"scan"）；旧会话无 kind 时按 frame_id
        兼容：最小 frame_id 的一组视为标定帧，其余视为扫描帧。
        """
        calib: Dict[str, FrameData] = {}
        scan: Dict[str, FrameData] = {}
        has_kind = any(f.kind for flist in frames.values() for f in flist)
        if has_kind:
            for cid, flist in frames.items():
                for f in flist:  # 已按 frame_id 升序，后者覆盖前者取最新
                    if f.kind == "scan":
                        scan[cid] = f
                    else:
                        calib[cid] = f
        else:
            all_ids = sorted({f.frame_id for flist in frames.values()
                              for f in flist})
            calib_id = all_ids[0] if all_ids else None
            for cid, flist in frames.items():
                for f in flist:
                    if f.frame_id == calib_id:
                        calib[cid] = f
                    else:
                        scan[cid] = f
        return calib, scan

    def _load_fixed_session(self, session: OfflineSession,
                            frames: Dict[str, List[FrameData]]):
        """模式 A：恢复标定帧/扫描帧/标定结果，开放扫描拼接。"""
        calib_latest, scan_latest = self._split_session_frames(frames)
        ws = self.shell.workspace_multi()

        # 1. 恢复标定结果（会话 meta.json 中 calibration 字段）
        calib_ok = False
        calib_data = session.get_meta("calibration")
        self.fixed_workflow.reset()
        self.calibration_engine.topology = session.get_meta('calibration_topology') or 'star'
        if self.calibration_engine.topology not in ('star', 'chain'):
            self.calibration_engine.topology = 'star'
        if calib_data:
            ok, msg = self.calibration_engine.load_from_dict(calib_data)
            if ok:
                calib_ok = True
            else:
                self.shell.log(f"会话标定结果恢复失败: {msg}", "warn")

        # 2. 确定参考相机并进入标定阶段
        ref_id = self.calibration_engine.reference_id if calib_ok else None
        camera_ids = sorted(set(calib_latest) | set(scan_latest))
        if not camera_ids and calib_ok:
            camera_ids = sorted({cid for pair in self.calibration_engine.pair_results for cid in pair})
        if not camera_ids:
            self.shell.log("会话为空，无帧数据可加载", "warn")
            return
        if ref_id not in camera_ids:
            ref_id = camera_ids[0]
        ok, msg = self.fixed_workflow.start_calibration(ref_id)
        if not ok:
            self.shell.log(f"加载会话失败: {msg}", "error")
            return

        # 3. 回填标定帧（markers 已随会话落盘恢复，无需重新检测）
        failed = []
        for cid, frame in calib_latest.items():
            ok, msg = self.fixed_workflow.add_calibration_frame(frame)
            if not ok:
                failed.append(cid)
                self.shell.log(f"加载 {cid} 标定帧失败: {msg}", "warn")
        if failed:
            self.shell.log(f"部分相机标定帧未加载: {failed}", "warn")

        if calib_ok:
            valid, reason = self.fixed_workflow.restore_calibration_state()
            if not valid:
                calib_ok = False
                self.calibration_engine.pair_results.clear()
                ws.clear_calibration_results()
                self.shell.log('加载的外参未通过完整性门禁：' + reason, 'warn')
        self._sync_multi_topology()

        # 4. 回填扫描帧（需标定结果支持进入扫描阶段）
        scan_loaded = False
        if scan_latest:
            if calib_ok:
                ok_scan, msg_scan = self.fixed_workflow.start_scanning()
                if ok_scan:
                    for cid, frame in scan_latest.items():
                        ok, msg = self.fixed_workflow.add_scan_frame(frame)
                        if ok:
                            scan_loaded = True
                        else:
                            self.shell.log(f"加载 {cid} 扫描帧失败: {msg}", "warn")
                else:
                    self.shell.log(
                        f"会话扫描帧未恢复（无法进入扫描阶段: {msg_scan}），"
                        "请重新标定后拍摄", "warn")
            else:
                self.shell.log(
                    "会话含扫描帧但无标定结果，已仅恢复标定帧；"
                    "请重新检测/标定后再拍摄扫描帧", "warn")

        # 5. UI 回填
        ws.reset_camera_grid(camera_ids, enable_controls=False)
        # 相机仍在线时开放单相机控制（2D 预览 / 3D 拍摄 / 检测）
        for cid in camera_ids:
            card = ws.camera_grid().card(cid)
            if card is not None:
                card.set_controls_enabled(
                    self.camera_manager.is_connected(cid))
        for cid, frame in calib_latest.items():
            ws.camera_grid().set_frame(cid, frame)
            ws.camera_grid().set_frame_kind(cid, "标定帧")
            ws.camera_grid().set_marker_count(cid, len(frame.markers))
            ws.camera_grid().set_covis_status(cid, len(frame.markers) > 0)
        for cid, frame in scan_latest.items():
            ws.camera_grid().set_frame(cid, frame)
            ws.camera_grid().set_frame_kind(cid, "扫描帧")

        if calib_ok:
            pairs = _pairs_from_engine(self.calibration_engine)
            score = _score_from_pairs(pairs)
            ws.viewer().set_reference(self.fixed_workflow.reference_id)
            ws.on_calibrate_done(pairs, score, quality_passed=True)
            self._autosave_calibration()
            if scan_loaded:
                ws.set_state("locked")
                self.shell.log(
                    f"会话加载完成: 标定结果已恢复（{len(pairs)} 对），"
                    f"{len(scan_latest)} 台相机扫描帧已恢复，可直接拼接", "success")
            else:
                ok_scan, msg_scan = self.fixed_workflow.start_scanning()
                ws.set_state("locked" if ok_scan else "calibrated")
                self.shell.log(
                    f"会话加载完成: 标定结果已恢复（{len(pairs)} 对），"
                    + ("可拍摄扫描帧并拼接" if ok_scan else msg_scan), "success" if ok_scan else "warn")
        else:
            # 标定帧 markers 已随会话恢复时跳过「检测」步骤
            if calib_latest and all(f.markers for f in calib_latest.values()):
                ws.set_state("detected")
                self.shell.log(
                    "会话加载完成: 标定帧与标记已恢复，可直接「计算外参」", "success")
            else:
                ws.set_state("captured")
                self.shell.log(
                    "会话加载完成: 标定帧已恢复（无标记数据，请重新检测）", "success")
        self.shell.set_dirty(True)

    # ------------------------------------------------------------------
    # 工具方法
    # ------------------------------------------------------------------
    def _run_background(self, work, on_done, must_finish=False, name=None):
        """后台执行 work()，完成后主线程回调 on_done(result, error)。

        must_finish=True：B 类"必须完成"任务（会话保存/写盘/导出）。
            关窗时 cleanup 对其**无超时等待**（数据完整性优先），
            且禁止落入 pending→os._exit 名单（否则用户以为存好了实际丢数据）。
        name：任务名，cleanup warning 的唯一现场指认；缺省从调用栈推断
            （traceback.extract_stack()[-2] 取调用方方法名，零调用点改动）。
        """
        from ui_common.worker_thread import WorkerThread
        from .background_delivery import BackgroundDelivery
        if getattr(self, '_cleaned', False):
            return
        if name is None:
            import traceback
            name = traceback.extract_stack()[-2].name
        project_task = name.startswith('project_')
        inspection = name in ('calibration_inspection', 'capture_parameters', 'device_disconnect', 'recognition_parameters', 'device_status')
        if self.shell._presentation == 'industrial' and not project_task and not inspection:
            self.projects.prepare(self._current_mode)
        if name not in ('offline_preview', 'db_frame_preview', 'db_open_project', 'db_mutation') and not project_task and not inspection and self.shell._presentation == 'industrial':
            self.frame_db.restore(self._current_mode)
        def archive_work():
            result = work()
            if name not in ('offline_preview', 'db_frame_preview', 'db_open_project', 'db_mutation') and not project_task and not inspection:
                self.frame_db.archive_context(result)
            return result
        worker = WorkerThread(archive_work)
        worker._task_name = name
        worker._must_finish = must_finish
        self._workers.append(worker)

        def _wrapped_done(result, error):
            update_metadata = name not in ('offline_preview', 'db_frame_preview', 'db_open_project', 'db_mutation') and not project_task and not inspection
            if error is None and update_metadata:
                try:
                    self.frame_db.synchronize(result)
                    self.frame_db._changed(self._current_mode)
                except Exception as exc:
                    self.shell.log('DB元数据更新失败：' + str(exc), 'error')
            on_done(result, error)
            if error is None and self.shell._presentation == 'industrial':
                database = self.frame_db.databases[self._current_mode]
                self.recognition.available.update((self._current_mode, database.directory, frame.database_id,
                    database.records[frame.database_id].revision) for frame in self.frame_db._frames(result)
                    if frame.database_id in database.records)
            if error is None and update_metadata:
                try:
                    self.frame_db.synchronize()
                except Exception as exc:
                    self.shell.log('DB元数据更新失败：' + str(exc), 'error')

        # 基类 QThread.finished：线程真正退出后才摘除引用并交 Qt 回收。
        # 不能挂在 result_ready 上（run() 内发射、线程仍在运行），
        # 也不能挂在已遮蔽的自定义信号上，否则运行中析构 → __fastfail。
        worker._delivery = BackgroundDelivery(self, worker, _wrapped_done)
        worker.start()
        self.shell.workspace_robot()._refresh_actions()
        if hasattr(self.shell, '_industrial_ribbon'):
            self.shell._industrial_ribbon.update_status()

    def _on_worker_thread_finished(self, worker):
        """线程退出回调：从引用池摘除并调度 Qt 回收。"""
        if worker in self._workers:
            self._workers.remove(worker)
        worker.deleteLater()
        if getattr(self, '_cleaned', False):
            return
        self.shell.workspace_robot()._refresh_actions()
        if hasattr(self.shell, '_industrial_ribbon'):
            self.shell._industrial_ribbon.update_status()

    def cleanup(self):
        """清理资源（关闭窗口时调用）。幂等：aboutToQuit 与 main 尾部可能各调一次。

        返回超时仍未结束的后台 worker 列表（正常情况为空列表）。
        """
        if getattr(self, "_cleaned", False):
            return getattr(self, "_pending_workers", [])
        self._cleaned = True
        editor = getattr(self, '_postprocess_window', None)
        if editor is not None and not editor._closed:
            editor.shutdown()
        # 停止实时取景（线程 stop 会等待在飞采集完成，带超时）
        if self._preview_thread is not None:
            self._preview_thread.stop()
            self._preview_thread = None
        self._card_preview_timer.stop()
        self._card_preview_active.clear()
        self.recognition.close()
        # 任务分级等待（E5：SDK 无法加超时，改为语义分级）：
        #   B 类 must_finish：无超时等待，禁止进 pending→os._exit 名单（数据完整性优先）；
        #   A 类：有界等待 3s，超时保留引用并记 warning（os._exit 安全网名单）。
        # os._exit 之后 warning 是唯一现场，必须带任务名。
        pending = []
        for worker in list(self._workers):
            if not worker.isRunning():
                continue
            task_name = getattr(worker, "_task_name", "?")
            if getattr(worker, "_must_finish", False):
                logger.info(f"[cleanup] 等待必须完成的任务结束: {task_name}")
                worker.wait()
                continue
            if not worker.wait(3000):
                pending.append(worker)
                logger.warning(
                    f"[cleanup] 后台任务超过 3 秒未结束，保留引用待其自然退出: {task_name} ({worker})")
        self._workers[:] = pending
        self._pending_workers = pending
        if self._sdk_initialized:
            self.camera_manager.shutdown()
            self._sdk_initialized = False
        if not pending:
            self.projects.cleanup()
        return pending

    def abandon_must_finish_tasks(self):
        """用户明确放弃等待：把运行中的 B 类任务降级为 A 类（cleanup 不再无超时等待）。

        由 closeEvent 的"放弃保存并关闭"调用。数据完整性由原子写兜底。
        返回被降级的任务名列表。
        """
        abandoned = []
        for worker in list(self._workers):
            if worker.isRunning() and getattr(worker, "_must_finish", False):
                worker._must_finish = False
                task_name = getattr(worker, "_task_name", "?")
                abandoned.append(task_name)
                logger.warning(f"[cleanup] 任务被用户放弃等待，降级为可放弃: {task_name}")
        return abandoned
