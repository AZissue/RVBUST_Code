const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 38000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ===== Multer config =====
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    cb(null, name + ext);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } }); // 5MB

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '..', 'project')));

// ===== Auth middleware =====
async function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: '未登录' });
  try {
    const decoded = Buffer.from(token, 'base64').toString('utf8');
    const [userId, username, role] = decoded.split(':');
    const user = await db.getUserById(userId);
    if (!user || !user.isActive) return res.status(401).json({ error: '用户无效' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: '认证失败' });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: '需要管理员权限' });
  next();
}

// ===== Helper =====
function makeToken(user) {
  return Buffer.from(`${user.id}:${user.username}:${user.role}`).toString('base64');
}

// ===== Auth Routes =====
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await db.getUserByUsername(username);
  if (!user || !user.isActive) {
    return res.status(401).json({ error: '用户名或密码错误' });
  }
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    return res.status(401).json({ error: '用户名或密码错误' });
  }
  const token = makeToken(user);
  res.json({ token, user: { id: user.id, username: user.username, name: user.name, role: user.role, color: user.color, email: user.email, phone: user.phone } });
});

app.post('/api/logout', auth, (req, res) => {
  res.json({ success: true });
});

// ===== User Routes =====
app.get('/api/users', auth, async (req, res) => {
  const users = (await db.getUsers()).map(u => ({ ...u, password: undefined }));
  res.json(users);
});

app.post('/api/users', auth, adminOnly, async (req, res) => {
  const user = req.body;
  const existing = await db.getUserByUsername(user.username);
  if (existing) return res.status(400).json({ error: '账号已存在' });
  // 密码哈希
  if (user.password) {
    user.password = await bcrypt.hash(user.password, 10);
  }
  const newUser = await db.createUser(user);
  res.status(201).json({ ...newUser, password: undefined });
});

app.put('/api/users/:id', auth, adminOnly, async (req, res) => {
  const { id } = req.params;
  const fields = req.body;
  delete fields.id;
  await db.updateUser(id, fields);
  res.json({ success: true });
});

// ===== Ticket Routes =====
app.get('/api/tickets', auth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const result = await db.getTickets(page, limit);
  res.json(result);
});

app.get('/api/tickets/:id', auth, async (req, res) => {
  const ticket = await db.getTicketById(req.params.id);
  if (!ticket) return res.status(404).json({ error: '工单不存在' });
  res.json(ticket);
});

app.post('/api/tickets', auth, async (req, res) => {
  const ticket = req.body;
  if (!ticket.creatorId) {
    ticket.creatorId = req.user.id;
  }
  const newTicket = await db.createTicket(ticket);
  res.status(201).json(newTicket);
});

app.put('/api/tickets/:id', auth, async (req, res) => {
  const { id } = req.params;
  const fields = req.body;
  delete fields.id;
  fields.updatedAt = new Date().toISOString();
  await db.updateTicket(id, fields);
  res.json({ success: true });
});

app.delete('/api/tickets/:id', auth, adminOnly, async (req, res) => {
  await db.deleteTicket(req.params.id);
  res.json({ success: true });
});

// ===== Ticket Comments =====
app.post('/api/tickets/:id/comments', auth, async (req, res) => {
  const ticket = await db.getTicketById(req.params.id);
  if (!ticket) return res.status(404).json({ error: '工单不存在' });
  const comment = { ...req.body, userId: req.user.id, userName: req.user.name, createdAt: new Date().toISOString() };
  ticket.comments = ticket.comments || [];
  ticket.comments.push(comment);
  await db.updateTicket(req.params.id, { comments: ticket.comments, updatedAt: new Date().toISOString() });
  res.json({ success: true });
});

// ===== Customer Routes =====
app.get('/api/customers', auth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const result = await db.getCustomers(page, limit);
  res.json(result);
});

app.get('/api/customers/:id', auth, async (req, res) => {
  const customer = await db.getCustomerById(req.params.id);
  if (!customer) return res.status(404).json({ error: '客户不存在' });
  res.json(customer);
});

app.post('/api/customers', auth, async (req, res) => {
  const customer = req.body;
  const newCustomer = await db.createCustomer(customer);
  res.status(201).json(newCustomer);
});

app.put('/api/customers/:id', auth, async (req, res) => {
  const { id } = req.params;
  const fields = req.body;
  delete fields.id;
  await db.updateCustomer(id, fields);
  res.json({ success: true });
});

app.delete('/api/customers/:id', auth, adminOnly, async (req, res) => {
  await db.deleteCustomer(req.params.id);
  res.json({ success: true });
});

// ===== Upload Routes =====
app.post('/api/upload', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: '未上传文件' });
  const url = `/uploads/${req.file.filename}`;
  res.json({ url, name: req.file.originalname });
});
app.use('/uploads', express.static(UPLOAD_DIR));

// ===== Customer Interactions =====
app.get('/api/customers/:id/interactions', auth, async (req, res) => {
  const customer = await db.getCustomerById(req.params.id);
  if (!customer) return res.status(404).json({ error: '客户不存在' });
  res.json(customer.interactions || []);
});
app.post('/api/customers/:id/interactions', auth, async (req, res) => {
  const customer = await db.getCustomerById(req.params.id);
  if (!customer) return res.status(404).json({ error: '客户不存在' });
  const interaction = { ...req.body, id: db.generateId(), createdAt: new Date().toISOString(), userId: req.user.id, userName: req.user.name };
  customer.interactions = customer.interactions || [];
  customer.interactions.push(interaction);
  await db.updateCustomer(req.params.id, { interactions: customer.interactions });
  res.status(201).json(interaction);
});
app.delete('/api/customers/:id/interactions/:iid', auth, async (req, res) => {
  const customer = await db.getCustomerById(req.params.id);
  if (!customer || !customer.interactions) return res.status(404).json({ error: '不存在' });
  customer.interactions = customer.interactions.filter(i => i.id !== req.params.iid);
  await db.updateCustomer(req.params.id, { interactions: customer.interactions });
  res.json({ success: true });
});

// ===== Export Routes =====
app.get('/api/export/tickets', auth, async (req, res) => {
  const ticketsRes = await db.getTickets(1, 999999);
  const tickets = ticketsRes.list || [];
  const customersRes = await db.getCustomers(1, 999999);
  const customers = customersRes.list || [];
  const users = await db.getUsers();
  const format = req.query.format || 'json';
  if (format === 'csv') {
    const headers = ['工单号','标题','客户','负责人','状态','优先级','分类','创建时间','更新时间','截止日期','描述'];
    const rows = tickets.map(t => {
      const c = customers.find(x => x.id === t.customerId);
      const e = users.find(x => x.id === t.engineerId);
      return [
        t.id, t.title, c ? c.name : '', e ? e.name : '', t.status, t.priority, t.category,
        t.createdAt, t.updatedAt, t.dueDate, (t.description || '').replace(/\n/g, ' ')
      ].map(v => `"${String(v).replace(/"/g, '""')}"`);
    });
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=tickets.csv');
    res.send('\uFEFF' + csv);
  } else {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename=tickets.json');
    res.json(tickets);
  }
});

app.get('/api/export/customers', auth, async (req, res) => {
  const customersRes = await db.getCustomers(1, 999999);
  const customers = customersRes.list || [];
  const format = req.query.format || 'json';
  if (format === 'csv') {
    const headers = ['客户名称','联系人','电话','邮箱','地址','行业','等级','设备数','创建时间'];
    const rows = customers.map(c => [
      c.name, c.contact, c.phone, c.email, c.address, c.industry, c.level,
      c.devices ? c.devices.length : 0, c.createdAt
    ].map(v => `"${String(v).replace(/"/g, '""')}"`));
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=customers.csv');
    res.send('\uFEFF' + csv);
  } else {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename=customers.json');
    res.json(customers);
  }
});

// ===== Reminders =====
app.get('/api/reminders', auth, async (req, res) => {
  const list = await db.getReminders();
  res.json(list.filter(r => r.toUserId === req.user.id));
});
app.post('/api/reminders', auth, async (req, res) => {
  const reminder = { ...req.body, createdAt: new Date().toISOString(), read: false };
  const newR = await db.addReminder(reminder);
  res.status(201).json(newR);
});
app.put('/api/reminders/:id/read', auth, async (req, res) => {
  await db.markReminderRead(req.params.id);
  res.json({ success: true });
});
app.post('/api/reminders/clear', auth, async (req, res) => {
  await db.clearReminders(req.user.id);
  res.json({ success: true });
});

// ===== Stats =====
app.get('/api/stats', auth, async (req, res) => {
  const ticketsRes = await db.getTickets(1, 999999);
  const tickets = ticketsRes.list || [];
  const users = (await db.getUsers()).filter(u => u.role === 'engineer');
  const customersRes = await db.getCustomers(1, 999999);
  const customers = customersRes.list || [];
  const completed = tickets.filter(t => t.status === 'resolved');

  res.json({
    totalTickets: tickets.length,
    pending: tickets.filter(t => t.status === 'pending').length,
    processing: tickets.filter(t => t.status === 'processing').length,
    resolved: completed.length,
    urgent: tickets.filter(t => t.priority === 'high' && t.status !== 'resolved').length,
    engineerCount: users.length,
    customerCount: customers.length,
    engineers: users.map(u => {
      const ut = tickets.filter(t => t.engineerId === u.id);
      return {
        id: u.id,
        name: u.name,
        color: u.color,
        total: ut.length,
        resolved: ut.filter(t => t.status === 'resolved').length,
        processing: ut.filter(t => t.status === 'processing').length,
        pending: ut.filter(t => t.status === 'pending').length
      };
    })
  });
});

// ===== Start =====
app.listen(PORT, () => {
  console.log(`[CRM Server] http://localhost:${PORT}`);
  console.log(`[API Base] http://localhost:${PORT}/api`);
  console.log(`[DB] ${path.resolve(__dirname, 'data', 'crm.db')}`);
});
